globalThis.__nitro_main__ = import.meta.url;
import { a as toEventHandler, c as serve, i as defineLazyEventHandler, n as HTTPError, r as defineHandler, s as NodeResponse, t as H3Core } from "./_libs/h3+rou3+srvx.mjs";
import { i as withoutTrailingSlash, n as joinURL, r as withLeadingSlash, t as decodePath } from "./_libs/ufo.mjs";
import { promises } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, resolve } from "node:path";
//#region #nitro-vite-setup
function lazyService(loader) {
	let promise, mod;
	return { fetch(req) {
		if (mod) return mod.fetch(req);
		if (!promise) promise = loader().then((_mod) => mod = _mod.default || _mod);
		return promise.then((mod) => mod.fetch(req));
	} };
}
var services = { ["ssr"]: lazyService(() => import("./_ssr/ssr.mjs")) };
globalThis.__nitro_vite_envs__ = services;
//#endregion
//#region node_modules/nitro/dist/runtime/internal/route-rules.mjs
var headers = ((m) => function headersRouteRule(event) {
	for (const [key, value] of Object.entries(m.options || {})) event.res.headers.set(key, value);
});
//#endregion
//#region #nitro/virtual/public-assets-data
var public_assets_data_default = {
	"/assets/ActivityTable-D-ro4Hh-.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1199-+/45p/do+l5c6d9ZO3mikBtxVoU\"",
		"mtime": "2026-07-21T16:53:48.667Z",
		"size": 4505,
		"path": "../public/assets/ActivityTable-D-ro4Hh-.js"
	},
	"/favicon.ico": {
		"type": "image/vnd.microsoft.icon",
		"etag": "\"3c2e-N7swDkM/eAyAZ54yufJz32tVVK4\"",
		"mtime": "2026-07-21T16:53:49.026Z",
		"size": 15406,
		"path": "../public/favicon.ico"
	},
	"/assets/AreaChart-BDm7Oqw4.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2ac2-O2tHyWikuluoUC9XhY23BvZCaH4\"",
		"mtime": "2026-07-21T16:53:48.667Z",
		"size": 10946,
		"path": "../public/assets/AreaChart-BDm7Oqw4.js"
	},
	"/assets/HeatmapPanel-ew4tGRvq.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"217f-JX5VJiHBwzvgFpQRdQWKLotZG4k\"",
		"mtime": "2026-07-21T16:53:48.667Z",
		"size": 8575,
		"path": "../public/assets/HeatmapPanel-ew4tGRvq.js"
	},
	"/assets/IncidentDetailModal-B0XsUN7g.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"12ca-DOuocT0G5HWDhPBVSjbd4k0xZNE\"",
		"mtime": "2026-07-21T16:53:48.667Z",
		"size": 4810,
		"path": "../public/assets/IncidentDetailModal-B0XsUN7g.js"
	},
	"/assets/Skeleton-CPsD2KF_.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"347-xbthZYN8lKhKJI70pcISg1ZILTw\"",
		"mtime": "2026-07-21T16:53:48.667Z",
		"size": 839,
		"path": "../public/assets/Skeleton-CPsD2KF_.js"
	},
	"/assets/admin-DN9kFy2j.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1917-Z4twEG1tapkImDtULCvjBeUv9ns\"",
		"mtime": "2026-07-21T16:53:48.668Z",
		"size": 6423,
		"path": "../public/assets/admin-DN9kFy2j.js"
	},
	"/assets/BarChart-CMJ0NE2e.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"138-8OpmhYUIlWEoPZRTjzCckYYvf68\"",
		"mtime": "2026-07-21T16:53:48.667Z",
		"size": 312,
		"path": "../public/assets/BarChart-CMJ0NE2e.js"
	},
	"/assets/alerts-BDffFfmL.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"10f5-QfwAM7N2LsvIMckOiHgTzjr/cuo\"",
		"mtime": "2026-07-21T16:53:48.668Z",
		"size": 4341,
		"path": "../public/assets/alerts-BDffFfmL.js"
	},
	"/assets/download-BXSkJsC0.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"e6-s+wrK3LgLNuXkrTL6MnbjwQsQ3g\"",
		"mtime": "2026-07-21T16:53:48.668Z",
		"size": 230,
		"path": "../public/assets/download-BXSkJsC0.js"
	},
	"/assets/api-BpDSqdlt.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"29ae-CO72tZA0S6M9p5XGAxFnuRwXB7c\"",
		"mtime": "2026-07-21T16:53:48.668Z",
		"size": 10670,
		"path": "../public/assets/api-BpDSqdlt.js"
	},
	"/assets/district-BMRrbela.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"9de-v4ZQu3gvHE0LJfLV4ULFQyKN1MM\"",
		"mtime": "2026-07-21T16:53:48.668Z",
		"size": 2526,
		"path": "../public/assets/district-BMRrbela.js"
	},
	"/assets/eye-DgGbFkfq.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"fe-ghOajlH+3u6wgK1i1SG9gkv8k1U\"",
		"mtime": "2026-07-21T16:53:48.668Z",
		"size": 254,
		"path": "../public/assets/eye-DgGbFkfq.js"
	},
	"/assets/file-text-Dm7KTrof.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"24b-NLEQD4oWngLMDKH8lvBhNymmJqc\"",
		"mtime": "2026-07-21T16:53:48.668Z",
		"size": 587,
		"path": "../public/assets/file-text-Dm7KTrof.js"
	},
	"/assets/fir-Dvpk6C_y.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2221-hpw31smz+3dUBw9AFvVN/dvKPBw\"",
		"mtime": "2026-07-21T16:53:48.668Z",
		"size": 8737,
		"path": "../public/assets/fir-Dvpk6C_y.js"
	},
	"/assets/funnel-IG-KEPFp.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"fe-4nQqn//OoDrO51CEwVwNwPV8h/k\"",
		"mtime": "2026-07-21T16:53:48.668Z",
		"size": 254,
		"path": "../public/assets/funnel-IG-KEPFp.js"
	},
	"/assets/cases-DyjZtA8n.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1f22-z6py1EX5ieHh/GWoLu28TYs75Q4\"",
		"mtime": "2026-07-21T16:53:48.668Z",
		"size": 7970,
		"path": "../public/assets/cases-DyjZtA8n.js"
	},
	"/assets/generateCategoricalChart-Ej4NmLwN.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5a4e1-3W7oCKd0NxTiZmVDoe21CN7QE9c\"",
		"mtime": "2026-07-21T16:53:48.668Z",
		"size": 369889,
		"path": "../public/assets/generateCategoricalChart-Ej4NmLwN.js"
	},
	"/assets/heatmap-B1RA03_Q.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"158e-lhgMmg+yiPeSpRkVizD7NY5/u7U\"",
		"mtime": "2026-07-21T16:53:48.669Z",
		"size": 5518,
		"path": "../public/assets/heatmap-B1RA03_Q.js"
	},
	"/assets/login-B_-43kHx.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1911-5T7hitKXyxQgsjD34EhYhihsu34\"",
		"mtime": "2026-07-21T16:53:48.669Z",
		"size": 6417,
		"path": "../public/assets/login-B_-43kHx.js"
	},
	"/assets/index-DfeREZQd.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"53520-N/+rW9PYdjwMQb4xN4bwke+/mEQ\"",
		"mtime": "2026-07-21T16:53:48.667Z",
		"size": 341280,
		"path": "../public/assets/index-DfeREZQd.js"
	},
	"/assets/predictive-NYaLusHH.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5049-93NLoeXr0QgTSbh2HT1GASTVqVM\"",
		"mtime": "2026-07-21T16:53:48.669Z",
		"size": 20553,
		"path": "../public/assets/predictive-NYaLusHH.js"
	},
	"/assets/plus-Qxg_mSsw.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"97-er/DJMllt3eH1DNF31aoouteFAU\"",
		"mtime": "2026-07-21T16:53:48.669Z",
		"size": 151,
		"path": "../public/assets/plus-Qxg_mSsw.js"
	},
	"/assets/ksp-logo-DgV97Jhx.png": {
		"type": "image/png",
		"etag": "\"46f37-3oD/37XS0/YDy9w2QWDmx68jm2M\"",
		"mtime": "2026-07-21T16:53:48.670Z",
		"size": 290615,
		"path": "../public/assets/ksp-logo-DgV97Jhx.png"
	},
	"/assets/relationships-Dc14Ap1L.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1b25-vL961jLsogo6A3OWXUDovNP0pMo\"",
		"mtime": "2026-07-21T16:53:48.669Z",
		"size": 6949,
		"path": "../public/assets/relationships-Dc14Ap1L.js"
	},
	"/assets/reports-DA8H1AkV.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"7817-miz5gprt9Mud6y8v/AjcLaH8PBg\"",
		"mtime": "2026-07-21T16:53:48.669Z",
		"size": 30743,
		"path": "../public/assets/reports-DA8H1AkV.js"
	},
	"/assets/routes-DLpRtZs2.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3915-xCvyGrnSGik9HjVe1C4ME9l89Lk\"",
		"mtime": "2026-07-21T16:53:48.669Z",
		"size": 14613,
		"path": "../public/assets/routes-DLpRtZs2.js"
	},
	"/assets/shield-B296Q3cE.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"10e-tlcY1JDhqx7yYNwXNP0lYQQzAPE\"",
		"mtime": "2026-07-21T16:53:48.669Z",
		"size": 270,
		"path": "../public/assets/shield-B296Q3cE.js"
	},
	"/assets/styles-Bfq1S4kv.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"18414-pxX3dv7+4TnRg5e0u2mZqtki8ZQ\"",
		"mtime": "2026-07-21T16:53:48.670Z",
		"size": 99348,
		"path": "../public/assets/styles-Bfq1S4kv.css"
	},
	"/assets/trending-up--3oXnN4n.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"12a-t6Qs5xWk3HTX9U45lQmyGrtSPQ4\"",
		"mtime": "2026-07-21T16:53:48.669Z",
		"size": 298,
		"path": "../public/assets/trending-up--3oXnN4n.js"
	},
	"/assets/triangle-alert-DlpzYuo6.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"107-Fzf1gzbi8rMKbBmovTTEc3PP0JU\"",
		"mtime": "2026-07-21T16:53:48.669Z",
		"size": 263,
		"path": "../public/assets/triangle-alert-DlpzYuo6.js"
	},
	"/assets/ui-DhIGVfx4.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"b367-IF/z0m5UfEHS+2+llHOz+9yymaA\"",
		"mtime": "2026-07-21T16:53:48.670Z",
		"size": 45927,
		"path": "../public/assets/ui-DhIGVfx4.js"
	},
	"/assets/useRouter-BJ5XiiId.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"21ad-UmZd5f/nXJDbSsKvk5NqhkbrzKE\"",
		"mtime": "2026-07-21T16:53:48.670Z",
		"size": 8621,
		"path": "../public/assets/useRouter-BJ5XiiId.js"
	},
	"/assets/user-ClGptIgL.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"c2-U/QQuTJ2Wl10PaU41+3JOHH2/g8\"",
		"mtime": "2026-07-21T16:53:48.670Z",
		"size": 194,
		"path": "../public/assets/user-ClGptIgL.js"
	},
	"/assets/users-Brvu2NZ5.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"130-rh4+I4L9Cyp9kXvnleQICIbQxKw\"",
		"mtime": "2026-07-21T16:53:48.670Z",
		"size": 304,
		"path": "../public/assets/users-Brvu2NZ5.js"
	},
	"/assets/vidhana-soudha-C2NJXAbl.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"595-UksP8yA+bOWaE2a1R1x2zuydBk8\"",
		"mtime": "2026-07-21T16:53:48.670Z",
		"size": 1429,
		"path": "../public/assets/vidhana-soudha-C2NJXAbl.js"
	},
	"/assets/zap-8q7DN0bj.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"104-AaWFt5CeYZhbyPfWStle605f5ao\"",
		"mtime": "2026-07-21T16:53:48.670Z",
		"size": 260,
		"path": "../public/assets/zap-8q7DN0bj.js"
	},
	"/assets/vidhana-soudha-CrJJjxG_.png": {
		"type": "image/png",
		"etag": "\"83ccc-gh/Bjm9VAL9Rk72MXPpt3p+7jUc\"",
		"mtime": "2026-07-21T16:53:48.670Z",
		"size": 539852,
		"path": "../public/assets/vidhana-soudha-CrJJjxG_.png"
	}
};
//#endregion
//#region #nitro/virtual/public-assets-node
function readAsset(id) {
	const serverDir = dirname(fileURLToPath(globalThis.__nitro_main__));
	return promises.readFile(resolve(serverDir, public_assets_data_default[id].path));
}
//#endregion
//#region #nitro/virtual/public-assets
var publicAssetBases = {};
function isPublicAssetURL(id = "") {
	if (public_assets_data_default[id]) return true;
	for (const base in publicAssetBases) if (id.startsWith(base)) return true;
	return false;
}
function getAsset(id) {
	return public_assets_data_default[id];
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/static.mjs
var METHODS = /* @__PURE__ */ new Set(["HEAD", "GET"]);
var EncodingMap = {
	gzip: ".gz",
	br: ".br",
	zstd: ".zst"
};
var static_default = defineHandler((event) => {
	if (event.req.method && !METHODS.has(event.req.method)) return;
	let id = decodePath(withLeadingSlash(withoutTrailingSlash(event.url.pathname)));
	let asset;
	const encodings = [...(event.req.headers.get("accept-encoding") || "").split(",").map((e) => EncodingMap[e.trim()]).filter(Boolean).sort(), ""];
	for (const encoding of encodings) for (const _id of [id + encoding, joinURL(id, "index.html" + encoding)]) {
		const _asset = getAsset(_id);
		if (_asset) {
			asset = _asset;
			id = _id;
			break;
		}
	}
	if (!asset) {
		if (isPublicAssetURL(id)) {
			event.res.headers.delete("Cache-Control");
			throw new HTTPError({ status: 404 });
		}
		return;
	}
	if (encodings.length > 1) event.res.headers.append("Vary", "Accept-Encoding");
	if (event.req.headers.get("if-none-match") === asset.etag) {
		event.res.status = 304;
		event.res.statusText = "Not Modified";
		return "";
	}
	const ifModifiedSinceH = event.req.headers.get("if-modified-since");
	const mtimeDate = new Date(asset.mtime);
	if (ifModifiedSinceH && asset.mtime && new Date(ifModifiedSinceH) >= mtimeDate) {
		event.res.status = 304;
		event.res.statusText = "Not Modified";
		return "";
	}
	if (asset.type) event.res.headers.set("Content-Type", asset.type);
	if (asset.etag && !event.res.headers.has("ETag")) event.res.headers.set("ETag", asset.etag);
	if (asset.mtime && !event.res.headers.has("Last-Modified")) event.res.headers.set("Last-Modified", mtimeDate.toUTCString());
	if (asset.encoding && !event.res.headers.has("Content-Encoding")) event.res.headers.set("Content-Encoding", asset.encoding);
	if (asset.size > 0 && !event.res.headers.has("Content-Length")) event.res.headers.set("Content-Length", asset.size.toString());
	return readAsset(id);
});
//#endregion
//#region #nitro/virtual/routing
var findRouteRules = /* @__PURE__ */ (() => {
	const $0 = [{
		name: "headers",
		route: "/assets/**",
		handler: headers,
		options: { "cache-control": "public, max-age=31536000, immutable" }
	}];
	return (m, p) => {
		let r = [];
		if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
		let s = p.split("/");
		if (s.length > 1) {
			if (s[1] === "assets") r.unshift({
				data: $0,
				params: { "_": s.slice(2).join("/") }
			});
		}
		return r;
	};
})();
var _lazy_QoP5i8 = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
var findRoute = /* @__PURE__ */ (() => {
	const data = {
		route: "/**",
		handler: _lazy_QoP5i8
	};
	return ((_m, p) => {
		return {
			data,
			params: { "_": p.slice(1) }
		};
	});
})();
var globalMiddleware = [toEventHandler(static_default)].filter(Boolean);
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/prod.mjs
var errorHandler = (error, event) => {
	const res = defaultHandler(error, event);
	return new NodeResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
	const unhandled = error.unhandled ?? !HTTPError.isError(error);
	const { status = 500, statusText = "" } = unhandled ? {} : error;
	if (status === 404) {
		const url = event.url || new URL(event.req.url);
		const baseURL = "/";
		if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) return {
			status: 302,
			headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
		};
	}
	const headers = new Headers(unhandled ? {} : error.headers);
	headers.set("content-type", "application/json; charset=utf-8");
	return {
		status,
		statusText,
		headers,
		body: {
			error: true,
			...unhandled ? {
				status,
				unhandled: true
			} : typeof error.toJSON === "function" ? error.toJSON() : {
				status,
				statusText,
				message: error.message
			}
		}
	};
}
//#endregion
//#region #nitro/virtual/error-handler
var errorHandlers = [errorHandler];
async function error_handler_default(error, event) {
	for (const handler of errorHandlers) try {
		const response = await handler(error, event, { defaultHandler });
		if (response) return response;
	} catch (error) {
		console.error(error);
	}
}
//#endregion
//#region #nitro/virtual/app
function createNitroApp() {
	const captureError = (error, errorCtx) => {
		if (errorCtx?.event) {
			const errors = errorCtx.event.req.context?.nitro?.errors;
			if (errors) errors.push({
				error,
				context: errorCtx
			});
		}
	};
	const h3App = createH3App({ onError(error, event) {
		return error_handler_default(error, event);
	} });
	let appHandler = (req) => {
		req.context ||= {};
		req.context.nitro = req.context.nitro || { errors: [] };
		return h3App.fetch(req);
	};
	return {
		fetch: appHandler,
		h3: h3App,
		hooks: void 0,
		captureError
	};
}
function createH3App(config) {
	const h3App = new H3Core(config);
	h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
	h3App["~middleware"].push(...globalMiddleware);
	h3App["~getMiddleware"] = (event, route) => {
		const pathname = event.url.pathname;
		const method = event.req.method;
		const middleware = [];
		const routeRules = getRouteRules(method, pathname);
		event.context.routeRules = routeRules?.routeRules;
		if (routeRules?.routeRuleMiddleware.length) middleware.push(...routeRules.routeRuleMiddleware);
		middleware.push(...h3App["~middleware"]);
		if (route?.data?.middleware?.length) middleware.push(...route.data.middleware);
		return middleware;
	};
	return h3App;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/app.mjs
var APP_ID = "default";
function useNitroApp() {
	let instance = useNitroApp._instance;
	if (instance) return instance;
	instance = useNitroApp._instance = createNitroApp();
	globalThis.__nitro__ = globalThis.__nitro__ || {};
	globalThis.__nitro__[APP_ID] = instance;
	return instance;
}
function getRouteRules(method, pathname) {
	const m = findRouteRules(method, pathname);
	if (!m?.length) return { routeRuleMiddleware: [] };
	const routeRules = {};
	for (const layer of m) for (const rule of layer.data) {
		const currentRule = routeRules[rule.name];
		if (currentRule) {
			if (rule.options === false) {
				delete routeRules[rule.name];
				continue;
			}
			if (typeof currentRule.options === "object" && typeof rule.options === "object") currentRule.options = {
				...currentRule.options,
				...rule.options
			};
			else currentRule.options = rule.options;
			currentRule.route = rule.route;
			currentRule.params = {
				...currentRule.params,
				...layer.params
			};
		} else if (rule.options !== false) routeRules[rule.name] = {
			...rule,
			params: layer.params
		};
	}
	const middleware = [];
	const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
	for (const rule of orderedRules) {
		if (rule.options === false || !rule.handler) continue;
		middleware.push(rule.handler(rule));
	}
	return {
		routeRules,
		routeRuleMiddleware: middleware
	};
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/hooks.mjs
function _captureError(error, type) {
	console.error(`[${type}]`, error);
	useNitroApp().captureError?.(error, { tags: [type] });
}
function trapUnhandledErrors() {
	process.on("unhandledRejection", (error) => _captureError(error, "unhandledRejection"));
	process.on("uncaughtException", (error) => _captureError(error, "uncaughtException"));
}
//#endregion
//#region #nitro/virtual/tracing
var tracingSrvxPlugins = [];
//#endregion
//#region node_modules/nitro/dist/presets/node/runtime/node-server.mjs
var _parsedPort = Number.parseInt(process.env.NITRO_PORT ?? process.env.PORT ?? "");
var port = Number.isNaN(_parsedPort) ? 3e3 : _parsedPort;
var host = process.env.NITRO_HOST || process.env.HOST;
var cert = process.env.NITRO_SSL_CERT;
var key = process.env.NITRO_SSL_KEY;
var nitroApp = useNitroApp();
serve({
	port,
	hostname: host,
	tls: cert && key ? {
		cert,
		key
	} : void 0,
	fetch: nitroApp.fetch,
	plugins: [...tracingSrvxPlugins]
});
trapUnhandledErrors();
var node_server_default = {};
//#endregion
export { node_server_default as default };
