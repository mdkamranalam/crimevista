import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { K as Calendar, M as FileText, P as FileChartColumn, R as Download, j as Funnel } from "../_libs/lucide-react.mjs";
import { a as Panel, i as PageHeader, n as Btn, o as StatTile, r as Chip, t as AppShell } from "./ui-Bwzm-qoz.mjs";
import { a as YAxis, d as Pie, f as Cell, h as Legend, l as CartesianGrid, m as Tooltip, n as PieChart, o as XAxis, p as ResponsiveContainer, r as BarChart, u as Bar } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/reports-BayvoylK.js
var import_jsx_runtime = require_jsx_runtime();
var MONTHS = [
	"Jan",
	"Feb",
	"Mar",
	"Apr",
	"May",
	"Jun",
	"Jul"
].map((m, i) => ({
	m,
	filed: 2200 + i * 80 + (i % 2 ? 120 : 0),
	solved: 1600 + i * 70
}));
var MIX = [
	{
		name: "Theft",
		value: 32,
		c: "var(--color-gold)"
	},
	{
		name: "Cyber",
		value: 22,
		c: "var(--color-info)"
	},
	{
		name: "Assault",
		value: 18,
		c: "var(--color-destructive)"
	},
	{
		name: "Fraud",
		value: 14,
		c: "var(--color-warning)"
	},
	{
		name: "Other",
		value: 14,
		c: "var(--color-success)"
	}
];
var SAVED = [
	{
		name: "Monthly SP Briefing",
		type: "Auto · PDF",
		scope: "State",
		updated: "2h ago"
	},
	{
		name: "District Performance Scorecard",
		type: "Auto · XLSX",
		scope: "All Districts",
		updated: "1d ago"
	},
	{
		name: "Cyber Crime Deep-Dive",
		type: "Manual",
		scope: "Bengaluru Urban",
		updated: "3d ago"
	},
	{
		name: "Predictive Model Audit",
		type: "Auto · PDF",
		scope: "State",
		updated: "5d ago"
	},
	{
		name: "Officer KPI Report",
		type: "Manual",
		scope: "Mysuru Zone",
		updated: "1w ago"
	}
];
function ReportsPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		title: "Reports & Analytics",
		subtitle: "Analytical exports",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: "Reports & Analytics",
				description: "Build, schedule and export command-ready intelligence reports",
				actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					variant: "outline",
					icon: Calendar,
					children: "Date range"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					icon: FileChartColumn,
					children: "New Report"
				})] })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatTile, {
						label: "Reports Generated",
						value: "1,284",
						hint: "This month",
						tone: "gold"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatTile, {
						label: "Auto-Scheduled",
						value: "42",
						hint: "Active jobs",
						tone: "info"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatTile, {
						label: "Downloads",
						value: "7,821",
						hint: "Last 30d",
						tone: "success"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatTile, {
						label: "Distribution Lists",
						value: "18",
						tone: "warning"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-1 xl:grid-cols-[1.5fr_1fr] gap-4 md:gap-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
					title: "FIRs Filed vs Solved",
					subtitle: "Monthly · state-wide",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "h-[260px]",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BarChart, {
							data: MONTHS,
							margin: {
								top: 4,
								right: 8,
								bottom: 0,
								left: -18
							},
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
									stroke: "oklch(1 0 0 / 0.06)",
									vertical: false
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
									dataKey: "m",
									tick: {
										fontSize: 10,
										fill: "oklch(1 0 0 / 0.5)"
									},
									axisLine: false,
									tickLine: false
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
									tick: {
										fontSize: 10,
										fill: "oklch(1 0 0 / 0.5)"
									},
									axisLine: false,
									tickLine: false
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, { contentStyle: {
									background: "var(--color-navy-elev)",
									border: "1px solid var(--color-hairline)",
									borderRadius: 8,
									fontSize: 11
								} }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Legend, { wrapperStyle: { fontSize: 11 } }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
									dataKey: "filed",
									fill: "var(--color-gold)",
									radius: [
										4,
										4,
										0,
										0
									],
									barSize: 16,
									name: "Filed"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
									dataKey: "solved",
									fill: "var(--color-info)",
									radius: [
										4,
										4,
										0,
										0
									],
									barSize: 16,
									name: "Solved"
								})
							]
						}) })
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
					title: "Category Mix",
					subtitle: "Share of total FIRs (YTD)",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "h-[260px]",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PieChart, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pie, {
								data: MIX,
								innerRadius: 55,
								outerRadius: 90,
								paddingAngle: 2,
								dataKey: "value",
								children: MIX.map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cell, {
									fill: s.c,
									stroke: "var(--color-navy-card)",
									strokeWidth: 2
								}, i))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, { contentStyle: {
								background: "var(--color-navy-elev)",
								border: "1px solid var(--color-hairline)",
								borderRadius: 8,
								fontSize: 11
							} }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Legend, { wrapperStyle: { fontSize: 11 } })
						] }) })
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
				title: "Saved Reports",
				subtitle: "Automated and manual analytical outputs",
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					variant: "outline",
					icon: Funnel,
					children: "Filter"
				}),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "overflow-x-auto -mx-4 md:-mx-5 px-4 md:px-5",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
						className: "w-full text-[12.5px] min-w-[700px]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "text-[10.5px] uppercase tracking-wider text-secondary text-left border-b hairline",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-2 font-semibold",
									children: "Report"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-2 font-semibold",
									children: "Type"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-2 font-semibold",
									children: "Scope"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-2 font-semibold",
									children: "Updated"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-2 font-semibold text-right",
									children: "Actions"
								})
							]
						}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: SAVED.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "border-b hairline hover:bg-white/[0.03]",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
									className: "py-2.5 flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "w-3.5 h-3.5 text-primary" }), r.name]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "py-2.5",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
										tone: "info",
										children: r.type
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "py-2.5 text-secondary",
									children: r.scope
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "py-2.5 text-secondary",
									children: r.updated
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "py-2.5 text-right",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "inline-flex gap-1.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
											variant: "outline",
											children: "Preview"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
											icon: Download,
											children: "PDF"
										})]
									})
								})
							]
						}, r.name)) })]
					})
				})
			})
		]
	});
}
//#endregion
export { ReportsPage as component };
