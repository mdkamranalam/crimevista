import { i as __toESM } from "../_runtime.mjs";
import { n as require_jsx_runtime, r as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { R as Download, i as User, m as Search, r as Users, t as Zap, v as Network } from "../_libs/lucide-react.mjs";
import { a as Panel, i as PageHeader, n as Btn, o as StatTile, r as Chip, t as AppShell } from "./ui-Bwzm-qoz.mjs";
import { t as api } from "./api-CLd47u8k.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/relationships-BOLflrJs.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var PERSONS_FALLBACK = [
	{
		id: "P-8842",
		name: "Ramesh K.",
		role: "Suspect",
		cases: 12,
		links: 24,
		risk: "Critical"
	},
	{
		id: "P-8841",
		name: "Suresh M.",
		role: "Person of Interest",
		cases: 8,
		links: 15,
		risk: "High"
	},
	{
		id: "P-8840",
		name: "Vinay R.",
		role: "Associate",
		cases: 5,
		links: 22,
		risk: "High"
	},
	{
		id: "P-8839",
		name: "Prakash S.",
		role: "Witness",
		cases: 3,
		links: 6,
		risk: "Low"
	},
	{
		id: "P-8838",
		name: "Manoj T.",
		role: "Suspect",
		cases: 9,
		links: 18,
		risk: "High"
	},
	{
		id: "P-8837",
		name: "Deepak N.",
		role: "Associate",
		cases: 4,
		links: 11,
		risk: "Medium"
	}
];
var NODES = [
	{
		x: 50,
		y: 50,
		r: 22,
		label: "Ramesh K.",
		tone: "danger"
	},
	{
		x: 22,
		y: 30,
		r: 14,
		label: "Suresh",
		tone: "warning"
	},
	{
		x: 78,
		y: 32,
		r: 14,
		label: "Vinay",
		tone: "warning"
	},
	{
		x: 18,
		y: 72,
		r: 12,
		label: "Manoj",
		tone: "warning"
	},
	{
		x: 82,
		y: 74,
		r: 12,
		label: "Deepak",
		tone: "info"
	},
	{
		x: 50,
		y: 88,
		r: 10,
		label: "Prakash",
		tone: "success"
	},
	{
		x: 35,
		y: 15,
		r: 8,
		label: "N1",
		tone: "info"
	},
	{
		x: 65,
		y: 15,
		r: 8,
		label: "N2",
		tone: "info"
	}
];
var EDGES = [
	[0, 1],
	[0, 2],
	[0, 3],
	[0, 4],
	[0, 5],
	[1, 3],
	[2, 4],
	[1, 6],
	[2, 7],
	[3, 5]
];
var toneColor = (t) => ({
	danger: "var(--color-destructive)",
	warning: "var(--color-warning)",
	info: "var(--color-info)",
	success: "var(--color-success)"
})[t];
function RelPage() {
	const [persons, setPersons] = (0, import_react.useState)(PERSONS_FALLBACK);
	(0, import_react.useEffect)(() => {
		api.getNetworkAnalysis("CASE-2026-BLR-101").then((data) => {
			if (data && data.nodes && data.nodes.length > 0) {
				const mapped = data.nodes.map((n, idx) => ({
					id: n.id.slice(0, 8),
					name: n.label.split(" (")[0],
					role: n.type === "person" ? idx === 0 ? "Suspect" : "Associate" : "Case Record",
					cases: idx === 0 ? 12 : Math.max(1, 5 - idx),
					links: Math.max(2, 15 - idx * 2),
					risk: idx === 0 ? "Critical" : idx < 3 ? "High" : "Medium"
				}));
				setPersons(mapped);
			}
		});
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		title: "Relationship Intelligence",
		subtitle: "Graph analysis across cases",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: "Relationship Intelligence",
				description: "Discover hidden links between persons, gangs and cases",
				actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					variant: "outline",
					icon: Download,
					children: "Export Graph"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					icon: Zap,
					children: "Run AI Analysis"
				})] })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatTile, {
						label: "Persons Tracked",
						value: "12,842",
						hint: "Across all cases",
						tone: "info"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatTile, {
						label: "Active Gangs",
						value: "47",
						hint: "Under surveillance",
						tone: "danger"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatTile, {
						label: "Relationships",
						value: "34,921",
						hint: "Graph edges",
						tone: "gold"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatTile, {
						label: "AI Confidence",
						value: "88.6%",
						hint: "Link prediction",
						tone: "success"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-1 xl:grid-cols-[1.4fr_1fr] gap-4 md:gap-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
					title: "Relationship Graph — Ramesh K. Network",
					subtitle: "24 direct links · 3 clusters detected",
					action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
						tone: "gold",
						children: "AI"
					}),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative panel-inset aspect-[4/3] rounded-md overflow-hidden",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
							viewBox: "0 0 100 100",
							className: "w-full h-full",
							children: [EDGES.map(([a, b], i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
								x1: NODES[a].x,
								y1: NODES[a].y,
								x2: NODES[b].x,
								y2: NODES[b].y,
								stroke: "oklch(1 0 0 / 0.15)",
								strokeWidth: "0.3"
							}, i)), NODES.map((n, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
									cx: n.x,
									cy: n.y,
									r: n.r / 4 + 2,
									fill: toneColor(n.tone),
									opacity: .25
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
									cx: n.x,
									cy: n.y,
									r: n.r / 6 + 1,
									fill: toneColor(n.tone)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
									x: n.x,
									y: n.y + n.r / 4 + 5,
									fill: "oklch(0.9 0 0)",
									fontSize: "2.4",
									textAnchor: "middle",
									fontWeight: "600",
									children: n.label
								})
							] }, i))]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "absolute top-3 right-3 panel-inset px-2 py-1.5 text-[10px] space-y-1",
							children: [
								["Critical", "danger"],
								["High", "warning"],
								["Medium", "info"],
								["Low", "success"]
							].map(([l, t]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "w-2 h-2 rounded-full",
									style: { background: toneColor(t) }
								}), l]
							}, l))
						})]
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
					title: "Insights",
					subtitle: "AI-generated relationship signals",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "space-y-2.5",
						children: [
							{
								i: "Ramesh K. and Suresh M. co-appear in 6 FIRs",
								tag: "Strong link",
								tone: "danger"
							},
							{
								i: "Cluster of 8 suspects operating in Ballari–Mysuru corridor",
								tag: "Gang pattern",
								tone: "warning"
							},
							{
								i: "New link discovered between Vinay R. and drug case KA-3421",
								tag: "New",
								tone: "gold"
							},
							{
								i: "Prakash S. is a common witness across 3 fraud cases",
								tag: "Anomaly",
								tone: "info"
							},
							{
								i: "Manoj T. phone records match 4 crime scenes",
								tag: "Evidence",
								tone: "danger"
							}
						].map((x, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "panel-inset px-3 py-2.5 flex items-start gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Network, { className: "w-4 h-4 text-primary mt-0.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex-1 min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-[12.5px]",
									children: x.i
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
									tone: x.tone,
									className: "mt-1.5",
									children: x.tag
								})]
							})]
						}, i))
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				title: "Persons of Interest",
				subtitle: "Ranked by graph centrality",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2 mb-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-secondary" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							placeholder: "Search person, alias, phone or FIR...",
							className: "w-full panel-inset pl-9 pr-3 h-9 text-[12.5px] rounded-md focus:outline-none focus:ring-1 focus:ring-primary/60"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
						variant: "outline",
						icon: Users,
						children: "Filter"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "overflow-x-auto -mx-4 md:-mx-5 px-4 md:px-5",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
						className: "w-full text-[12.5px] min-w-[700px]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "text-[10.5px] uppercase tracking-wider text-secondary text-left border-b hairline",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-2 font-semibold",
									children: "ID"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-2 font-semibold",
									children: "Name"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-2 font-semibold",
									children: "Role"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-2 font-semibold",
									children: "Cases"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-2 font-semibold",
									children: "Links"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-2 font-semibold",
									children: "Risk"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-2 font-semibold text-right",
									children: "Action"
								})
							]
						}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: persons.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "border-b hairline hover:bg-white/[0.03]",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "py-2.5 font-mono text-primary",
									children: p.id
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
									className: "py-2.5 flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { className: "w-3.5 h-3.5 text-secondary" }), p.name]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "py-2.5 text-secondary",
									children: p.role
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "py-2.5 font-mono",
									children: p.cases
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "py-2.5 font-mono",
									children: p.links
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "py-2.5",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
										tone: p.risk === "Critical" ? "danger" : p.risk === "High" ? "warning" : p.risk === "Medium" ? "info" : "success",
										children: p.risk
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "py-2.5 text-right",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
										variant: "outline",
										children: "Open"
									})
								})
							]
						}, p.id)) })]
					})
				})]
			})
		]
	});
}
//#endregion
export { RelPage as component };
