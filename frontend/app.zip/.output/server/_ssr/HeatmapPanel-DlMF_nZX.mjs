import { i as __toESM } from "../_runtime.mjs";
import { n as require_jsx_runtime, r as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { C as MapPin, U as ChevronRight, a as TriangleAlert, n as X, x as Map } from "../_libs/lucide-react.mjs";
import { n as Btn } from "./ui-Bwzm-qoz.mjs";
import { t as api } from "./api-CLd47u8k.mjs";
import { n as Skeleton } from "./Skeleton-D98sCtxl.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/HeatmapPanel-DlMF_nZX.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function HotspotDetailModal({ hotspot, onClose }) {
	const [incidents, setIncidents] = (0, import_react.useState)([]);
	const [loading, setLoading] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (hotspot) {
			setLoading(true);
			const districtName = hotspot.name.split(" (")[0];
			api.getIncidents({
				district: districtName,
				limit: 10
			}).then((data) => {
				setIncidents(data.items || []);
				setLoading(false);
			});
		}
	}, [hotspot]);
	if (!hotspot) return null;
	const toneForStatus = (status) => {
		const s = (status || "").toLowerCase();
		if (s.includes("solved") || s.includes("closed")) return "text-success bg-success/15";
		if (s.includes("investigation")) return "text-warning bg-warning/15";
		return "text-info bg-info/15";
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "panel w-full max-w-2xl max-h-[90vh] overflow-hidden flex flex-col shadow-2xl ring-1 ring-white/10 animate-in fade-in zoom-in-95 duration-200",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start justify-between p-4 md:p-5 border-b border-white/10 bg-white/[0.02]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
								className: "text-lg font-semibold tracking-tight text-foreground",
								children: ["Hotspot #", hotspot.rank]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: `text-[10px] px-1.5 py-0.5 rounded font-semibold ${hotspot.tone}`,
								children: [hotspot.level, " Intensity"]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm text-secondary font-medium flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "w-3.5 h-3.5" }), hotspot.name]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: onClose,
						className: "p-1.5 rounded-md hover:bg-white/10 text-secondary hover:text-white transition-colors",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "w-5 h-5" })
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex-1 overflow-y-auto p-4 md:p-5 space-y-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
							className: "text-[13.5px] font-semibold flex items-center gap-2 text-primary",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "w-4 h-4" }), " Supporting Incidents"]
						}), loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-10 w-full" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-10 w-full" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-10 w-full" })
							]
						}) : incidents.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "panel-inset p-4",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "space-y-3",
								children: incidents.map((inc) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "flex flex-col md:flex-row md:items-center gap-2 text-sm justify-between border-b border-white/5 pb-2 last:border-0 last:pb-0",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-semibold px-2 py-0.5 rounded bg-white/5 font-mono",
											children: inc.case_number || inc.id.substring(0, 8)
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: inc.crime_type })]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-xs text-secondary",
											children: new Date(inc.date_time).toLocaleDateString("en-IN")
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: `text-[10px] font-semibold px-2 py-0.5 rounded ${toneForStatus(inc.status)}`,
											children: inc.status || "Under Investigation"
										})]
									})]
								}, inc.id))
							})
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "panel-inset p-4 text-center text-sm text-secondary",
							children: "No detailed incidents found for this cluster."
						})]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "p-4 md:p-5 border-t border-white/10 bg-white/[0.01] flex items-center justify-end gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
						variant: "outline",
						onClick: onClose,
						children: "Close"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
						variant: "primary",
						icon: Map,
						children: "View on Full Map"
					})]
				})
			]
		})
	});
}
var FALLBACK_HOTSPOTS = [
	{
		rank: 1,
		name: "Koramangala, Bengaluru",
		level: "Very High",
		tone: "bg-destructive/25 text-destructive"
	},
	{
		rank: 2,
		name: "Mysuru City",
		level: "High",
		tone: "bg-warning/25 text-warning"
	},
	{
		rank: 3,
		name: "Yeshwanthpur, Bengaluru",
		level: "High",
		tone: "bg-warning/25 text-warning"
	},
	{
		rank: 4,
		name: "Ballari City",
		level: "Medium",
		tone: "bg-info/25 text-info"
	},
	{
		rank: 5,
		name: "Hubli City",
		level: "Medium",
		tone: "bg-info/25 text-info"
	}
];
function HeatmapPanel() {
	const [hotspots, setHotspots] = (0, import_react.useState)(FALLBACK_HOTSPOTS);
	const [selectedHotspot, setSelectedHotspot] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		api.getHotspots().then((data) => {
			if (data && data.hotspots && data.hotspots.length > 0) {
				const mapped = data.hotspots.slice(0, 5).map((h, idx) => {
					const score = h.score || h.incident_count / 100;
					const level = score >= .85 ? "Very High" : score >= .7 ? "High" : "Medium";
					const tone = score >= .85 ? "bg-destructive/25 text-destructive" : score >= .7 ? "bg-warning/25 text-warning" : "bg-info/25 text-info";
					return {
						rank: idx + 1,
						name: `${h.district} (${h.crime_type || "Cluster"})`,
						level,
						tone
					};
				});
				setHotspots(mapped);
			}
		});
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "panel p-5 flex flex-col",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between mb-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-[15px] font-semibold",
					children: "Karnataka Crime Overview"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[11.5px] text-secondary mt-0.5",
					children: "Live crime density across all districts"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					className: "panel-inset text-[11.5px] px-2.5 py-1.5 outline-none",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Last 7 Days" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Last 30 Days" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Last 90 Days" })
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-1 xl:grid-cols-[1.4fr_1fr] gap-4 flex-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapCanvas, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-[11.5px] uppercase tracking-wider text-secondary font-semibold mb-2",
						children: "Top Hotspots"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "space-y-1.5",
						children: hotspots.map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							onClick: () => setSelectedHotspot(h),
							className: "flex items-center gap-3 panel-inset px-3 py-2.5 hover:border-primary/40 transition-colors cursor-pointer",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "w-6 h-6 rounded font-mono text-[11px] font-bold bg-primary/15 text-primary flex items-center justify-center",
									children: h.rank
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex-1 text-[12.5px] font-medium",
									children: h.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: `text-[10px] px-1.5 py-0.5 rounded font-semibold ${h.tone}`,
									children: h.level
								})
							]
						}, h.rank))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/heatmap",
						className: "mt-3 w-full gold-chip rounded-md py-2 text-[12px] font-semibold flex items-center justify-center gap-1 hover:brightness-110 block text-center",
						children: ["View Full Heatmap ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "w-3.5 h-3.5" })]
					})
				] })]
			}),
			selectedHotspot && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HotspotDetailModal, {
				hotspot: selectedHotspot,
				onClose: () => setSelectedHotspot(null)
			})
		]
	});
}
function MapCanvas() {
	const hotspots = [
		{
			cx: 210,
			cy: 300,
			r: 42,
			c: "oklch(0.66 0.22 25)"
		},
		{
			cx: 175,
			cy: 260,
			r: 32,
			c: "oklch(0.72 0.2 55)"
		},
		{
			cx: 260,
			cy: 195,
			r: 26,
			c: "oklch(0.78 0.14 85)"
		},
		{
			cx: 155,
			cy: 155,
			r: 22,
			c: "oklch(0.72 0.17 155)"
		},
		{
			cx: 235,
			cy: 240,
			r: 20,
			c: "oklch(0.72 0.17 155)"
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative rounded-md overflow-hidden panel-inset aspect-[4/3] xl:aspect-auto min-h-[320px]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
			viewBox: "0 0 400 420",
			className: "w-full h-full",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("defs", { children: [hotspots.map((h, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("radialGradient", {
					id: `hg${i}`,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
						offset: "0%",
						stopColor: h.c,
						stopOpacity: "0.9"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
						offset: "100%",
						stopColor: h.c,
						stopOpacity: "0"
					})]
				}, i)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pattern", {
					id: "grid",
					width: "24",
					height: "24",
					patternUnits: "userSpaceOnUse",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
						d: "M24 0H0V24",
						fill: "none",
						stroke: "oklch(1 0 0 / 0.04)",
						strokeWidth: "1"
					})
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					width: "400",
					height: "420",
					fill: "url(#grid)"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
					d: "M90 90 L170 70 L230 90 L280 130 L300 180 L320 240 L280 300 L250 360 L200 380 L150 360 L110 320 L90 260 L70 200 L80 140 Z",
					fill: "oklch(0.32 0.05 258 / 0.7)",
					stroke: "oklch(0.78 0.14 85 / 0.35)",
					strokeWidth: "1.2"
				}),
				hotspots.map((h, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: h.cx,
					cy: h.cy,
					r: h.r,
					fill: `url(#hg${i})`
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: h.cx,
					cy: h.cy,
					r: "3",
					fill: h.c
				})] }, i)),
				[
					[
						"Belagavi",
						110,
						130
					],
					[
						"Hubballi",
						145,
						165
					],
					[
						"Dharwad",
						165,
						200
					],
					[
						"Ballari",
						260,
						190
					],
					[
						"Shivamogga",
						175,
						235
					],
					[
						"Tumakuru",
						235,
						245
					],
					[
						"Mysuru",
						175,
						275
					],
					[
						"Bengaluru",
						220,
						305
					],
					[
						"Mangaluru",
						120,
						300
					]
				].map(([name, x, y]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
					x,
					y,
					fill: "oklch(0.88 0.02 250)",
					fontSize: "9",
					fontWeight: "500",
					textAnchor: "middle",
					children: name
				}, name))
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "absolute bottom-3 left-3 panel-inset px-3 py-2 space-y-1 text-[10.5px]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "font-semibold text-secondary mb-1 uppercase tracking-wider",
				children: "Intensity"
			}), [
				["Very High", "oklch(0.66 0.22 25)"],
				["High", "oklch(0.72 0.2 55)"],
				["Medium", "oklch(0.78 0.14 85)"],
				["Low", "oklch(0.72 0.17 155)"]
			].map(([l, c]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "w-2.5 h-2.5 rounded-sm",
					style: { background: c }
				}), l]
			}, l))]
		})]
	});
}
//#endregion
export { HeatmapPanel as t };
