import { i as __toESM } from "../_runtime.mjs";
import { n as vidhana_soudha_default, t as ksp_logo_default } from "./vidhana-soudha-CCYvDeTj.mjs";
import { n as require_jsx_runtime, r as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { _ as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { F as Eye, I as EyeOff, T as Lock, i as User, u as Shield } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/login-CVF93hiN.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function LoginPage() {
	const navigate = useNavigate();
	const [officerId, setOfficerId] = (0, import_react.useState)("");
	const [password, setPassword] = (0, import_react.useState)("");
	const [showPassword, setShowPassword] = (0, import_react.useState)(false);
	const [remember, setRemember] = (0, import_react.useState)(false);
	const [loading, setLoading] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)("");
	const handleLogin = (e) => {
		e.preventDefault();
		setLoading(true);
		setError("");
		setTimeout(() => {
			if (officerId.toUpperCase() === "SPVIJAY" && password === "crimevista123") navigate({ to: "/" });
			else {
				setLoading(false);
				setError("Invalid Officer ID or Password");
			}
		}, 800);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen grid lg:grid-cols-2 bg-background",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "hidden lg:flex flex-col justify-between bg-sidebar relative overflow-hidden p-12",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-br from-[#08172B] via-[#10294D] to-[#0B1F3A]" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative z-10",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: ksp_logo_default,
							alt: "Karnataka Police",
							className: "w-20 h-20 object-contain"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
								className: "text-5xl font-black",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-white",
									children: "Crime"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-primary",
									children: "Vista"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "uppercase tracking-[0.3em] text-secondary text-sm mt-2",
								children: "AI Crime Intelligence Platform"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-secondary text-sm",
								children: "Government of Karnataka"
							})
						] })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-20",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
								className: "text-4xl font-bold text-white leading-tight",
								children: [
									"Secure.",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
									"Intelligent.",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
									"Effective."
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-6 text-secondary text-lg leading-8",
								children: "Empowering Karnataka State Police with AI-powered crime analytics, hotspot detection, predictive policing and criminal relationship intelligence."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-10 rounded-xl border border-white/10 bg-white/5 p-5",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shield, { className: "text-primary w-6 h-6" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "font-semibold text-white",
										children: "State Crime Records Bureau"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-secondary text-sm mt-1",
										children: "Unified AI Crime Intelligence Platform"
									})] })]
								})
							})
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative z-10",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: vidhana_soudha_default,
						alt: "Vidhana Soudha",
						className: "w-[80%] mx-auto opacity-20"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "border-t border-white/10 mt-6 pt-5 flex justify-between text-sm text-secondary",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Karnataka State Police" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "CrimeVista v2.0" })]
					})]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex items-center justify-center p-8",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: handleLogin,
				className: "w-full max-w-md bg-card rounded-2xl border border-border p-8 shadow-xl space-y-6",
				children: [
					"          ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-center",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "lg:hidden flex justify-center mb-5",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: ksp_logo_default,
									alt: "KSP",
									className: "w-16 h-16 object-contain"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-3xl font-bold",
								children: "Officer Login"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-secondary mt-2",
								children: "Welcome back. Sign in to continue."
							})
						]
					}),
					error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "rounded-lg bg-red-500/10 border border-red-500/30 text-red-400 p-3 text-sm",
						children: error
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "block mb-2 text-sm font-medium",
						children: "Officer ID"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { className: "absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-secondary" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							required: true,
							value: officerId,
							onChange: (e) => setOfficerId(e.target.value),
							placeholder: "SPVIJAY",
							className: "w-full h-12 rounded-lg border border-border bg-background pl-11 pr-4 outline-none focus:border-primary"
						})]
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "block mb-2 text-sm font-medium",
						children: "Password"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-secondary" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								required: true,
								type: showPassword ? "text" : "password",
								value: password,
								onChange: (e) => setPassword(e.target.value),
								placeholder: "Enter Password",
								className: "w-full h-12 rounded-lg border border-border bg-background pl-11 pr-12 outline-none focus:border-primary"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setShowPassword(!showPassword),
								className: "absolute right-3 top-1/2 -translate-y-1/2",
								children: showPassword ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EyeOff, { className: "w-5 h-5 text-secondary" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "w-5 h-5 text-secondary" })
							})
						]
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "checkbox",
								checked: remember,
								onChange: (e) => setRemember(e.target.checked),
								className: "accent-yellow-500"
							}), "Remember Me"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "text-primary hover:underline",
							children: "Forgot Password?"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "submit",
						disabled: loading,
						className: "w-full h-12 rounded-lg bg-primary text-primary-foreground font-semibold hover:opacity-90 transition disabled:opacity-50",
						children: loading ? "Signing In..." : "Sign In"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-lg border border-border p-4 bg-secondary/20",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "font-semibold text-primary mb-3",
								children: "Demo Credentials"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex justify-between text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Officer ID" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-mono",
									children: "SPVIJAY"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex justify-between text-sm mt-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Password" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-mono",
									children: "crimevista123"
								})]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-center text-xs text-secondary",
						children: [
							"Karnataka State Police",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
							"State Crime Records Bureau"
						]
					})
				]
			})
		})]
	});
}
//#endregion
export { LoginPage as component };
