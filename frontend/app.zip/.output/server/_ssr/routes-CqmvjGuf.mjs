import { i as __toESM } from "../_runtime.mjs";
import { n as require_jsx_runtime, r as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { C as MapPin, H as CircleCheck, J as Brain, M as FileText, S as MapPinned, U as ChevronRight, X as BellRing, a as TriangleAlert, k as Info, o as TrendingUp, q as Briefcase, r as Users, s as TrendingDown, u as Shield, x as Map } from "../_libs/lucide-react.mjs";
import { a as Panel, n as Btn, r as Chip, s as cn, t as AppShell } from "./ui-Bwzm-qoz.mjs";
import { t as api } from "./api-CLd47u8k.mjs";
import { n as Skeleton, t as KpiSkeleton } from "./Skeleton-D98sCtxl.mjs";
import { t as ActivityTable } from "./ActivityTable-DI2W1HYp.mjs";
import { t as HeatmapPanel } from "./HeatmapPanel-DlMF_nZX.mjs";
import { a as YAxis, h as Legend, l as CartesianGrid, m as Tooltip, o as XAxis, p as ResponsiveContainer, r as BarChart, s as Area, t as AreaChart, u as Bar } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CqmvjGuf.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var TONE = {
	gold: "text-primary bg-primary/10 border-primary/30",
	info: "text-info bg-info/10 border-info/30",
	danger: "text-destructive bg-destructive/10 border-destructive/30",
	success: "text-success bg-success/10 border-success/30",
	warning: "text-warning bg-warning/10 border-warning/30"
};
function KpiCard({ label, value, delta, trend = "up", hint, icon: Icon, tone = "gold" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "panel px-6 py-5 transition-all duration-300 hover:-translate-y-1 hover:border-primary/40 hover:shadow-xl",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-start justify-between",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: cn("flex h-12 w-12 items-center justify-center rounded-xl border", TONE[tone]),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "h-5 w-5" })
			}), delta && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: cn("flex items-center gap-1 rounded-md px-2 py-1 text-xs font-semibold", trend === "up" ? "bg-success/15 text-success" : "bg-destructive/15 text-destructive"),
				children: [trend === "up" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingUp, { className: "h-3.5 w-3.5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingDown, { className: "h-3.5 w-3.5" }), delta]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-semibold uppercase tracking-[0.14em] text-slate-200",
					children: label
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-3 text-[42px] font-black leading-none tracking-tight text-white",
					children: value
				}),
				hint && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm leading-relaxed text-slate-300",
					children: hint
				})
			]
		})]
	});
}
var FALLBACK_ITEMS = [
	{
		icon: TriangleAlert,
		tone: "text-destructive bg-destructive/15",
		title: "Today's Threat",
		body: "Elevated vehicle-theft risk in Mysuru Urban Zone-3"
	},
	{
		icon: TrendingUp,
		tone: "text-warning bg-warning/15",
		title: "Crime Spike",
		body: "+23% robberies detected in Koramangala over 72h"
	},
	{
		icon: Users,
		tone: "text-info bg-info/15",
		title: "Repeat Offender",
		body: "Raghav S. flagged across 12 open cases (3 districts)"
	},
	{
		icon: Shield,
		tone: "text-primary bg-primary/15",
		title: "Gang Activity",
		body: "Coordinated pattern detected in Ballari district"
	},
	{
		icon: MapPin,
		tone: "text-success bg-success/15",
		title: "Patrol Recommendation",
		body: "Deploy 4 units to Yeshwanthpur between 21:00-02:00"
	}
];
function AiIntelligence() {
	const [items, setItems] = (0, import_react.useState)(FALLBACK_ITEMS);
	(0, import_react.useEffect)(() => {
		api.getAnomalies({ limit: 5 }).then((data) => {
			if (data && data.anomalies && data.anomalies.length > 0) {
				const icons = [
					TriangleAlert,
					TrendingUp,
					Users,
					Shield,
					MapPin
				];
				const tones = [
					"text-destructive bg-destructive/15",
					"text-warning bg-warning/15",
					"text-info bg-info/15",
					"text-primary bg-primary/15",
					"text-success bg-success/15"
				];
				const mapped = data.anomalies.slice(0, 5).map((a, idx) => ({
					icon: icons[idx % icons.length],
					tone: tones[idx % tones.length],
					title: a.anomaly_type || "High Severity Alert",
					body: `${a.crime_type} in ${a.district}: ${a.reason || "Flagged for urgent attention"}`
				}));
				setItems(mapped);
			}
		});
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "panel p-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between mb-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "w-10 h-10 rounded-lg gold-chip flex items-center justify-center",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Brain, { className: "w-5 h-5" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-[15px] font-semibold",
						children: "AI Intelligence Brief"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11.5px] text-secondary",
						children: "Model synthesis · updated live"
					})] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfidenceRing, { pct: 92 })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "space-y-2",
				children: items.map((it, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-start gap-3 panel-inset px-3 py-2.5 hover:border-primary/40 transition-colors",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: `w-8 h-8 rounded-md flex items-center justify-center shrink-0 ${it.tone}`,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(it.icon, { className: "w-4 h-4" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-[12.5px] font-semibold",
							children: it.title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-[11.5px] text-secondary leading-snug",
							children: it.body
						})]
					})]
				}, `${it.title}-${idx}`))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/predictive",
				className: "mt-4 w-full gold-chip rounded-md py-2 text-[12px] font-semibold hover:brightness-110 block text-center",
				children: "View Full Report"
			})
		]
	});
}
function ConfidenceRing({ pct }) {
	const r = 22;
	const c = 2 * Math.PI * r;
	const off = c - pct / 100 * c;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative w-14 h-14",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
			viewBox: "0 0 56 56",
			className: "w-full h-full -rotate-90",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "28",
				cy: "28",
				r,
				stroke: "oklch(1 0 0 / 0.08)",
				strokeWidth: "4",
				fill: "none"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "28",
				cy: "28",
				r,
				stroke: "var(--color-gold)",
				strokeWidth: "4",
				fill: "none",
				strokeDasharray: c,
				strokeDashoffset: off,
				strokeLinecap: "round"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "absolute inset-0 flex items-center justify-center font-mono text-[11px] font-bold text-primary",
			children: [pct, "%"]
		})]
	});
}
var TREND = [
	{
		d: "Mon",
		fir: 210,
		solved: 160
	},
	{
		d: "Tue",
		fir: 245,
		solved: 190
	},
	{
		d: "Wed",
		fir: 232,
		solved: 175
	},
	{
		d: "Thu",
		fir: 268,
		solved: 210
	},
	{
		d: "Fri",
		fir: 289,
		solved: 224
	},
	{
		d: "Sat",
		fir: 312,
		solved: 246
	},
	{
		d: "Sun",
		fir: 278,
		solved: 231
	}
];
var CATEGORY = [
	{
		c: "Theft",
		v: 72
	},
	{
		c: "Robbery",
		v: 68
	},
	{
		c: "Burglary",
		v: 56
	},
	{
		c: "Assault",
		v: 45
	},
	{
		c: "Cyber",
		v: 35
	},
	{
		c: "Fraud",
		v: 29
	}
];
var AXIS = {
	stroke: "oklch(1 0 0 / 0.35)",
	fontSize: 10
};
var TOOL = {
	contentStyle: {
		background: "var(--color-navy-elev)",
		border: "1px solid var(--color-hairline)",
		borderRadius: 8,
		fontSize: 11
	},
	labelStyle: { color: "var(--color-text-secondary)" }
};
function ChartsPanel() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid grid-cols-1 xl:grid-cols-2 gap-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "panel p-5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartHead, {
				title: "FIR Trend — Last 7 Days",
				subtitle: "Registrations vs resolutions across Karnataka",
				badge: "+12.5%"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "h-[260px] mt-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AreaChart, {
					data: TREND,
					margin: {
						top: 8,
						right: 8,
						bottom: 0,
						left: -12
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("defs", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("linearGradient", {
							id: "g1",
							x1: "0",
							y1: "0",
							x2: "0",
							y2: "1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
								offset: "0%",
								stopColor: "var(--color-gold)",
								stopOpacity: .5
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
								offset: "100%",
								stopColor: "var(--color-gold)",
								stopOpacity: 0
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("linearGradient", {
							id: "g2",
							x1: "0",
							y1: "0",
							x2: "0",
							y2: "1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
								offset: "0%",
								stopColor: "var(--color-info)",
								stopOpacity: .4
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
								offset: "100%",
								stopColor: "var(--color-info)",
								stopOpacity: 0
							})]
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
							stroke: "oklch(1 0 0 / 0.06)",
							vertical: false
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
							dataKey: "d",
							tick: AXIS,
							axisLine: false,
							tickLine: false
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
							tick: AXIS,
							axisLine: false,
							tickLine: false
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, { ...TOOL }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Legend, { wrapperStyle: { fontSize: 11 } }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
							type: "monotone",
							dataKey: "fir",
							name: "FIRs",
							stroke: "var(--color-gold)",
							strokeWidth: 2,
							fill: "url(#g1)"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
							type: "monotone",
							dataKey: "solved",
							name: "Solved",
							stroke: "var(--color-info)",
							strokeWidth: 2,
							fill: "url(#g2)"
						})
					]
				}) })
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "panel p-5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartHead, {
				title: "Top Predicted Crime Categories",
				subtitle: "Next-7-day predictive model output",
				badge: "AI · 92.4%"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "h-[260px] mt-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BarChart, {
					data: CATEGORY,
					layout: "vertical",
					margin: {
						top: 8,
						right: 16,
						bottom: 0,
						left: 8
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
							stroke: "oklch(1 0 0 / 0.06)",
							horizontal: false
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
							type: "number",
							tick: AXIS,
							axisLine: false,
							tickLine: false
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
							dataKey: "c",
							type: "category",
							tick: AXIS,
							axisLine: false,
							tickLine: false,
							width: 70
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
							...TOOL,
							cursor: { fill: "oklch(1 0 0 / 0.04)" }
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
							dataKey: "v",
							fill: "var(--color-gold)",
							radius: [
								0,
								4,
								4,
								0
							],
							barSize: 16
						})
					]
				}) })
			})]
		})]
	});
}
function ChartHead({ title, subtitle, badge }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-start justify-between",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
			className: "text-[14px] font-semibold",
			children: title
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-[11.5px] text-secondary mt-0.5",
			children: subtitle
		})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "gold-chip text-[10.5px] px-2 py-1 rounded font-mono font-semibold",
			children: badge
		})]
	});
}
function PatrolRecommendationPanel() {
	const [recommendations, setRecommendations] = (0, import_react.useState)([]);
	const [loading, setLoading] = (0, import_react.useState)(true);
	(0, import_react.useEffect)(() => {
		let isMounted = true;
		api.getPatrolRecommendations().then((data) => {
			if (isMounted) {
				setRecommendations(data.recommendations || []);
				setLoading(false);
			}
		}).catch(() => {
			if (isMounted) setLoading(false);
		});
		return () => {
			isMounted = false;
		};
	}, []);
	const getTone = (priority) => {
		switch (priority) {
			case "Critical": return "danger";
			case "High": return "warning";
			case "Medium": return "info";
			default: return "neutral";
		}
	};
	const getIcon = (priority) => {
		switch (priority) {
			case "Critical": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "w-4 h-4 text-danger" });
			case "High": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "w-4 h-4 text-warning" });
			case "Medium": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, { className: "w-4 h-4 text-info" });
			default: return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "w-4 h-4 text-secondary" });
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
		title: "Predictive Patrol Zones",
		subtitle: "AI-recommended deployment based on recent incident density",
		action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
			variant: "outline",
			size: "sm",
			icon: Map,
			children: "View on Map"
		}),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "space-y-3",
			children: loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-20 w-full" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-20 w-full" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-20 w-full" })
			] }) : recommendations.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-center py-6 text-secondary text-sm",
				children: "No active patrol recommendations at this time."
			}) : recommendations.slice(0, 4).map((rec) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "panel-inset p-3.5 flex flex-col md:flex-row gap-3 md:items-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex-1 space-y-1.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [
							getIcon(rec.priority),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "font-semibold text-sm",
								children: [
									"Zone ",
									rec.zone_id,
									" • ",
									rec.district
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
								tone: getTone(rec.priority),
								children: rec.priority
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-secondary leading-relaxed pl-6",
						children: rec.rationale
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "shrink-0 flex items-center gap-4 pl-6 md:pl-0 border-l border-white/5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-center px-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-lg font-bold text-primary",
							children: rec.incident_count
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-[10px] uppercase tracking-wider text-secondary",
							children: "Incidents"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
						variant: "primary",
						size: "sm",
						children: "Dispatch"
					})]
				})]
			}, rec.zone_id))
		})
	});
}
var LIVE_INITIAL = [
	"Vehicle theft cases increased by 23% in Mysuru Urban",
	"New hotspot detected in Koramangala, Bengaluru",
	"12 new FIRs registered in last 2 hours",
	"Gang activity detected in Ballari district"
];
function Dashboard() {
	const [summary, setSummary] = (0, import_react.useState)(null);
	const [liveTicker, setLiveTicker] = (0, import_react.useState)(LIVE_INITIAL);
	(0, import_react.useEffect)(() => {
		api.getDashboardSummary().then((data) => {
			setSummary(data);
			if (data && data.high_risk_districts?.length > 0) {
				const topDist = data.high_risk_districts[0].district;
				setLiveTicker([`High crime volume detected across ${topDist} (${data.high_risk_districts[0].incident_count} records)`, ...LIVE_INITIAL.slice(1)]);
			}
		});
	}, []);
	const totalFirs = summary?.total_incidents ? summary.total_incidents.toLocaleString() : "18,472";
	const activeInv = summary?.total_incidents ? Math.round(summary.total_incidents * .08).toLocaleString() : "1,482";
	const highRiskCnt = summary?.high_risk_districts ? summary.high_risk_districts.length.toString() : "5";
	const solvedCnt = summary?.total_incidents ? Math.round(summary.total_incidents * .53).toLocaleString() : "9,842";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		title: "Good Morning, SP Vijay Kumar 👋",
		subtitle: "Here's your intelligence brief for today",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "panel px-4 py-2.5 flex items-center gap-4 overflow-hidden",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2 shrink-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "live-dot" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-[11px] uppercase tracking-wider font-semibold text-destructive",
						children: "Live"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex gap-6 md:gap-8 overflow-x-auto scrollbar-thin text-[12px] text-secondary whitespace-nowrap",
					children: liveTicker.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "flex items-center gap-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "w-1.5 h-1.5 rounded-full bg-primary shrink-0" }), l]
					}, l))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between mb-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-[11.5px] uppercase tracking-wider font-semibold text-secondary",
					children: "Today's Overview"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					className: "text-[11.5px] text-primary flex items-center hover:brightness-110",
					children: ["View all ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "w-3.5 h-3.5" })]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-2 md:grid-cols-3 xl:grid-cols-6 gap-3 md:gap-4",
				children: !summary ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KpiSkeleton, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KpiSkeleton, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KpiSkeleton, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KpiSkeleton, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KpiSkeleton, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KpiSkeleton, {})
				] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KpiCard, {
						label: "Total FIRs Indexed",
						value: totalFirs,
						delta: "12.5%",
						trend: "up",
						hint: "state registry",
						icon: FileText,
						tone: "info"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KpiCard, {
						label: "Active Investigations",
						value: activeInv,
						delta: "8.3%",
						trend: "up",
						hint: "open cases",
						icon: Briefcase,
						tone: "gold"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KpiCard, {
						label: "High Risk Districts",
						value: highRiskCnt,
						delta: "2",
						trend: "up",
						hint: "top volume",
						icon: MapPinned,
						tone: "danger"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KpiCard, {
						label: "Solved Cases",
						value: solvedCnt,
						delta: "40.1%",
						trend: "up",
						hint: "year to date",
						icon: CircleCheck,
						tone: "success"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KpiCard, {
						label: "Prediction Accuracy",
						value: "92.4%",
						delta: "2.1%",
						trend: "up",
						hint: "AI model v4.2",
						icon: Brain,
						tone: "gold"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KpiCard, {
						label: "Emergency Alerts",
						value: "12",
						delta: "4.1%",
						trend: "down",
						hint: "active now",
						icon: BellRing,
						tone: "warning"
					})
				] })
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartsPanel, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-1 xl:grid-cols-[1.55fr_1fr] gap-4 md:gap-5 mb-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeatmapPanel, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AiIntelligence, {})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mb-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PatrolRecommendationPanel, {})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActivityTable, {})
		]
	});
}
//#endregion
export { Dashboard as component };
