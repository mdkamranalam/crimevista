import { i as __toESM } from "../_runtime.mjs";
import { n as require_jsx_runtime, r as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { K as Calendar, f as ShieldAlert, g as Plus, i as User, j as Funnel, m as Search, n as X, q as Briefcase } from "../_libs/lucide-react.mjs";
import { a as Panel, i as PageHeader, n as Btn, o as StatTile, r as Chip, t as AppShell } from "./ui-Bwzm-qoz.mjs";
import { t as api } from "./api-CLd47u8k.mjs";
import { t as ActivityTable } from "./ActivityTable-DI2W1HYp.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/cases-XN9B6WhJ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function CaseDetailModal({ caseItem, onClose }) {
	if (!caseItem) return null;
	const priorityTone = (p) => p === "Critical" ? "danger" : p === "High" ? "warning" : "info";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "panel w-full max-w-2xl max-h-[90vh] overflow-hidden flex flex-col shadow-2xl ring-1 ring-white/10 animate-in fade-in zoom-in-95 duration-200",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start justify-between p-4 md:p-5 border-b border-white/10 bg-white/[0.02]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "text-lg font-semibold tracking-tight text-foreground",
									children: caseItem.id
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
									tone: priorityTone(caseItem.priority),
									children: caseItem.priority
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, { children: caseItem.status })
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-secondary font-medium",
							children: caseItem.title
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: onClose,
						className: "p-1.5 rounded-md hover:bg-white/10 text-secondary hover:text-white transition-colors",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "w-5 h-5" })
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex-1 overflow-y-auto p-4 md:p-5 space-y-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 md:grid-cols-4 gap-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "panel-inset p-3 space-y-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-[11px] uppercase tracking-wider text-secondary flex items-center gap-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { className: "w-3.5 h-3.5" }), " Lead Officer"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-sm font-medium",
									children: caseItem.lead
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "panel-inset p-3 space-y-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-[11px] uppercase tracking-wider text-secondary flex items-center gap-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Briefcase, { className: "w-3.5 h-3.5" }), " Team Size"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-sm font-medium",
									children: [caseItem.team, " officers"]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "panel-inset p-3 space-y-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-[11px] uppercase tracking-wider text-secondary flex items-center gap-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldAlert, { className: "w-3.5 h-3.5" }), " Progress"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-sm font-medium",
									children: [caseItem.progress, "%"]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "panel-inset p-3 space-y-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-[11px] uppercase tracking-wider text-secondary flex items-center gap-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calendar, { className: "w-3.5 h-3.5" }), " Last Updated"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-sm font-medium",
									children: "Just now"
								})]
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "text-[13.5px] font-semibold text-primary",
							children: "Case Description"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "panel-inset p-4 text-sm text-secondary leading-relaxed",
							children: [
								"Active investigation regarding ",
								caseItem.title.toLowerCase(),
								". Team of ",
								caseItem.team,
								" officers led by ",
								caseItem.lead,
								" is currently analyzing connected incidents and syndicates. Progress stands at ",
								caseItem.progress,
								"%."
							]
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "p-4 md:p-5 border-t border-white/10 bg-white/[0.01] flex items-center justify-end gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
						variant: "outline",
						onClick: onClose,
						children: "Close"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
						variant: "primary",
						children: "Manage Team"
					})]
				})
			]
		})
	});
}
var CASES_FALLBACK = [
	{
		id: "C-3421",
		title: "Bengaluru vehicle theft ring",
		lead: "Insp. R. Sharma",
		team: 6,
		progress: 72,
		status: "Active",
		priority: "High"
	},
	{
		id: "C-3420",
		title: "Mysuru burglary series",
		lead: "SI. K. Naidu",
		team: 4,
		progress: 45,
		status: "Active",
		priority: "Medium"
	},
	{
		id: "C-3419",
		title: "Hubli cyber fraud syndicate",
		lead: "Insp. A. Iyer",
		team: 8,
		progress: 88,
		status: "Closing",
		priority: "Critical"
	},
	{
		id: "C-3418",
		title: "Ballari narcotics network",
		lead: "DySP. M. Rao",
		team: 10,
		progress: 32,
		status: "Active",
		priority: "Critical"
	},
	{
		id: "C-3417",
		title: "Mangaluru port smuggling",
		lead: "Insp. V. Shetty",
		team: 5,
		progress: 60,
		status: "Active",
		priority: "High"
	},
	{
		id: "C-3416",
		title: "Shivamogga kidnapping",
		lead: "DySP. L. Kumar",
		team: 7,
		progress: 22,
		status: "Active",
		priority: "Critical"
	}
];
var prTone = (p) => p === "Critical" ? "danger" : p === "High" ? "warning" : "info";
function CasesPage() {
	const [cases, setCases] = (0, import_react.useState)(CASES_FALLBACK);
	const [search, setSearch] = (0, import_react.useState)("");
	const [selectedCase, setSelectedCase] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		api.getCases().then((data) => {
			if (data && data.cases && data.cases.length > 0) {
				const mapped = data.cases.map((c, idx) => ({
					id: c.case_number || `C-${3421 - idx}`,
					title: c.title || `${c.district} ${c.crime_type || "Investigation"}`,
					lead: c.lead_officer || "Insp. R. Sharma",
					team: c.team_size || Math.max(3, 8 - idx),
					progress: c.progress || Math.min(95, 30 + idx * 12),
					status: c.status || "Active",
					priority: c.priority || (idx % 2 === 0 ? "High" : "Medium")
				}));
				setCases(mapped);
			}
		});
	}, []);
	const filteredCases = cases.filter((c) => !search || c.title.toLowerCase().includes(search.toLowerCase()) || c.id.toLowerCase().includes(search.toLowerCase()) || c.lead.toLowerCase().includes(search.toLowerCase()));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		title: "Case Management",
		subtitle: "Investigations, teams and progress",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: "Case Management",
				description: "1,482 active investigations · 6 zones · 218 lead officers",
				actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					variant: "outline",
					icon: Funnel,
					children: "Filters"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					icon: Plus,
					children: "New Case"
				})] })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatTile, {
						label: "Active",
						value: "1,482",
						tone: "warning"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatTile, {
						label: "Closing",
						value: "164",
						tone: "info"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatTile, {
						label: "Closed (30d)",
						value: "892",
						tone: "success"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatTile, {
						label: "Overdue",
						value: "37",
						tone: "danger"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				title: "Case Board",
				subtitle: "Ranked by priority and progress",
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
					tone: "gold",
					children: "Live"
				}),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2 mb-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-secondary" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							placeholder: "Search case, lead, tag...",
							value: search,
							onChange: (e) => setSearch(e.target.value),
							className: "w-full panel-inset pl-9 pr-3 h-9 text-[12.5px] rounded-md focus:outline-none focus:ring-1 focus:ring-primary/60"
						})]
					}), [
						"Priority",
						"Zone",
						"Status"
					].map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
						variant: "outline",
						icon: Funnel,
						children: f
					}, f))]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3",
					children: filteredCases.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "panel-inset p-4 space-y-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start justify-between gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "font-mono text-[11px] text-primary",
										children: c.id
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-[13.5px] font-semibold mt-0.5 leading-tight",
										children: c.title
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
									tone: prTone(c.priority),
									children: c.priority
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2 text-[11.5px] text-secondary",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { className: "w-3.5 h-3.5" }),
									" ",
									c.lead,
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "opacity-40",
										children: "·"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Briefcase, { className: "w-3.5 h-3.5" }),
									" ",
									c.team,
									" officers"
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between text-[11px] text-secondary mb-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Progress" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "font-mono",
									children: [c.progress, "%"]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "h-1.5 bg-white/5 rounded-full overflow-hidden",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "h-full bg-primary",
									style: { width: `${c.progress}%` }
								})
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between pt-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, { children: c.status }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
									variant: "outline",
									onClick: () => setSelectedCase(c),
									children: "Open"
								})]
							})
						]
					}, c.id))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActivityTable, {}),
			selectedCase && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CaseDetailModal, {
				caseItem: selectedCase,
				onClose: () => setSelectedCase(null)
			})
		]
	});
}
//#endregion
export { CasesPage as component };
