import { m as createFileRoute, p as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/district-DHIVk6pD.js
var $$splitComponentImporter = () => import("./district-B_hyJSvm.mjs");
var Route = createFileRoute("/district")({
	component: lazyRouteComponent($$splitComponentImporter, "component"),
	validateSearch: (search) => {
		return { name: search.name || "Bengaluru Urban" };
	}
});
//#endregion
export { Route as t };
