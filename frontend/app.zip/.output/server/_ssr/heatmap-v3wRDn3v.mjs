import { i as __toESM } from "../_runtime.mjs";
import { n as require_jsx_runtime, r as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { C as MapPin, D as Layers, R as Download, j as Funnel } from "../_libs/lucide-react.mjs";
import { a as Panel, i as PageHeader, n as Btn, o as StatTile, r as Chip, t as AppShell } from "./ui-Bwzm-qoz.mjs";
import { t as api } from "./api-CLd47u8k.mjs";
import { t as HeatmapPanel } from "./HeatmapPanel-DlMF_nZX.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/heatmap-v3wRDn3v.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var LAYERS_FALLBACK = [
	{
		name: "Vehicle Theft",
		count: 342,
		tone: "warning"
	},
	{
		name: "Burglary",
		count: 268,
		tone: "danger"
	},
	{
		name: "Cyber Fraud",
		count: 421,
		tone: "info"
	},
	{
		name: "Assault",
		count: 189,
		tone: "warning"
	},
	{
		name: "Narcotics",
		count: 97,
		tone: "gold"
	},
	{
		name: "Kidnapping",
		count: 42,
		tone: "danger"
	}
];
var DISTRICTS_FALLBACK = [
	{
		name: "Bengaluru Urban",
		firs: 1287,
		delta: "+12%",
		risk: "Very High"
	},
	{
		name: "Mysuru",
		firs: 642,
		delta: "+8%",
		risk: "High"
	},
	{
		name: "Ballari",
		firs: 421,
		delta: "+15%",
		risk: "High"
	},
	{
		name: "Dharwad",
		firs: 388,
		delta: "+3%",
		risk: "Medium"
	},
	{
		name: "Shivamogga",
		firs: 312,
		delta: "-1%",
		risk: "Medium"
	},
	{
		name: "Mangaluru",
		firs: 289,
		delta: "+5%",
		risk: "Medium"
	},
	{
		name: "Tumakuru",
		firs: 245,
		delta: "-4%",
		risk: "Low"
	},
	{
		name: "Belagavi",
		firs: 231,
		delta: "+2%",
		risk: "Low"
	}
];
function HeatmapRoute() {
	const [districts, setDistricts] = (0, import_react.useState)(DISTRICTS_FALLBACK);
	const [layers, setLayers] = (0, import_react.useState)(LAYERS_FALLBACK);
	(0, import_react.useEffect)(() => {
		api.getRiskScores().then((data) => {
			if (data && data.items && data.items.length > 0) {
				const mapped = data.items.map((r, idx) => ({
					name: r.district,
					firs: r.incident_count || Math.round(r.risk_score * 1500),
					delta: idx % 2 === 0 ? `+${(r.risk_score * 14).toFixed(1)}%` : `-${(r.risk_score * 8).toFixed(1)}%`,
					risk: r.risk_score >= .8 ? "Very High" : r.risk_score >= .6 ? "High" : r.risk_score >= .4 ? "Medium" : "Low"
				}));
				setDistricts(mapped);
			}
		});
		api.getDashboardSummary().then((data) => {
			if (data && data.recent_trends) {
				const mappedLayers = Object.entries(data.recent_trends).map(([name, count]) => ({
					name,
					count,
					tone: count > 3e3 ? "danger" : count > 2e3 ? "warning" : "info"
				}));
				if (mappedLayers.length > 0) setLayers(mappedLayers);
			}
		});
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		title: "Crime Heatmap",
		subtitle: "Live geographic crime density",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: "Crime Heatmap — Karnataka",
				description: "Interactive geographic density map · 30 districts · updated 2m ago",
				actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					variant: "outline",
					icon: Funnel,
					children: "Filters"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					icon: Download,
					children: "Export"
				})] })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatTile, {
						label: "Total Hotspots",
						value: `${districts.length}`,
						hint: "Live cluster count",
						tone: "danger"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatTile, {
						label: "Very High Risk",
						value: `${districts.filter((d) => d.risk.includes("High")).length}`,
						hint: "Immediate attention",
						tone: "warning"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatTile, {
						label: "Districts",
						value: `${districts.length || 30}`,
						hint: "All covered",
						tone: "info"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatTile, {
						label: "Predictions",
						value: "92.4%",
						hint: "Model accuracy",
						tone: "success"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-1 xl:grid-cols-[1fr_320px] gap-4 md:gap-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeatmapPanel, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
					title: "Active Layers",
					subtitle: "Toggle crime categories on the map",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "space-y-2",
						children: layers.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center gap-3 panel-inset px-3 py-2.5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Layers, { className: "w-4 h-4 text-secondary" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex-1 min-w-0",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-[12.5px] font-medium truncate",
										children: l.name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "text-[10.5px] text-secondary",
										children: [l.count, " incidents"]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "relative inline-flex cursor-pointer",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "checkbox",
											defaultChecked: true,
											className: "peer sr-only"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "w-8 h-4 bg-white/10 rounded-full peer-checked:bg-primary transition-colors" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute left-0.5 top-0.5 w-3 h-3 bg-white rounded-full peer-checked:translate-x-4 transition-transform" })
									]
								})
							]
						}, l.name))
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
				title: "District Breakdown",
				subtitle: "FIR density by district",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "overflow-x-auto -mx-4 md:-mx-5 px-4 md:px-5",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
						className: "w-full text-[12.5px] min-w-[600px]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "text-[10.5px] uppercase tracking-wider text-secondary text-left border-b hairline",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-2 font-semibold",
									children: "District"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-2 font-semibold",
									children: "FIRs (30d)"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-2 font-semibold",
									children: "Change"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-2 font-semibold",
									children: "Risk Level"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-2 font-semibold text-right",
									children: "Action"
								})
							]
						}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: districts.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "border-b hairline hover:bg-white/[0.03]",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
									className: "py-2.5 flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "w-3.5 h-3.5 text-primary" }), d.name]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "py-2.5 font-mono",
									children: d.firs.toLocaleString()
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: `py-2.5 font-mono ${d.delta.startsWith("+") ? "text-warning" : "text-success"}`,
									children: d.delta
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "py-2.5",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
										tone: d.risk === "Very High" ? "danger" : d.risk === "High" ? "warning" : d.risk === "Medium" ? "info" : "success",
										children: d.risk
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "py-2.5 text-right",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
										variant: "outline",
										children: "Drill down"
									})
								})
							]
						}, d.name)) })]
					})
				})
			})
		]
	});
}
//#endregion
export { HeatmapRoute as component };
