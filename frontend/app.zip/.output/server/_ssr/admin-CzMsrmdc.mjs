import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { B as Cpu, O as Key, Z as Activity, g as Plus, m as Search, p as Settings, r as Users, u as Shield, z as Database } from "../_libs/lucide-react.mjs";
import { a as Panel, i as PageHeader, n as Btn, o as StatTile, r as Chip, t as AppShell } from "./ui-Bwzm-qoz.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin-CzMsrmdc.js
var import_jsx_runtime = require_jsx_runtime();
var USERS = [
	{
		name: "SP Vijay Kumar",
		email: "vijay.kumar@ksp.gov.in",
		role: "State Admin",
		zone: "State HQ",
		status: "Active"
	},
	{
		name: "DySP L. Kumar",
		email: "l.kumar@ksp.gov.in",
		role: "Zone Commander",
		zone: "Shivamogga",
		status: "Active"
	},
	{
		name: "Insp. R. Sharma",
		email: "r.sharma@ksp.gov.in",
		role: "Investigator",
		zone: "Bengaluru Urban",
		status: "Active"
	},
	{
		name: "SI K. Naidu",
		email: "k.naidu@ksp.gov.in",
		role: "Officer",
		zone: "Mysuru",
		status: "Suspended"
	},
	{
		name: "Insp. A. Iyer",
		email: "a.iyer@ksp.gov.in",
		role: "Investigator",
		zone: "Dharwad",
		status: "Active"
	},
	{
		name: "DySP M. Rao",
		email: "m.rao@ksp.gov.in",
		role: "Zone Commander",
		zone: "Ballari",
		status: "Active"
	}
];
function AdminPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		title: "Administration",
		subtitle: "Users, roles and system health",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: "Administration",
				description: "Manage users, permissions, integrations and platform health",
				actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					variant: "outline",
					icon: Settings,
					children: "System Settings"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					icon: Plus,
					children: "Add User"
				})] })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatTile, {
						label: "Users",
						value: "1,842",
						hint: "+24 this month",
						tone: "info"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatTile, {
						label: "Active Roles",
						value: "14",
						tone: "gold"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatTile, {
						label: "API Keys",
						value: "27",
						hint: "7 rotating",
						tone: "warning"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatTile, {
						label: "System Uptime",
						value: "99.98%",
						hint: "30-day",
						tone: "success"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-1 xl:grid-cols-[1.5fr_1fr] gap-4 md:gap-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
					title: "Users & Roles",
					subtitle: "Manage officer accounts",
					action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
						tone: "gold",
						children: "RBAC"
					}),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2 mb-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-secondary" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								placeholder: "Search user or role...",
								className: "w-full panel-inset pl-9 pr-3 h-9 text-[12.5px] rounded-md focus:outline-none focus:ring-1 focus:ring-primary/60"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
							variant: "outline",
							icon: Shield,
							children: "Roles"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "overflow-x-auto -mx-4 md:-mx-5 px-4 md:px-5",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
							className: "w-full text-[12.5px] min-w-[600px]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "text-[10.5px] uppercase tracking-wider text-secondary text-left border-b hairline",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "py-2 font-semibold",
										children: "User"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "py-2 font-semibold",
										children: "Role"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "py-2 font-semibold",
										children: "Zone"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "py-2 font-semibold",
										children: "Status"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "py-2 font-semibold text-right",
										children: "Action"
									})
								]
							}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: USERS.map((u) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "border-b hairline hover:bg-white/[0.03]",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-2.5",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "w-7 h-7 rounded-full bg-gradient-to-br from-primary/60 to-primary/20 border border-primary/40 flex items-center justify-center text-[10px] font-bold text-primary-foreground",
												children: u.name.split(" ").slice(-1)[0][0]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "min-w-0",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "font-medium truncate",
													children: u.name
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "text-[10.5px] text-secondary truncate",
													children: u.email
												})]
											})]
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-2.5",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
											tone: "gold",
											children: u.role
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-2.5 text-secondary",
										children: u.zone
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-2.5",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
											tone: u.status === "Active" ? "success" : "danger",
											children: u.status
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-2.5 text-right",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
											variant: "outline",
											children: "Manage"
										})
									})
								]
							}, u.email)) })]
						})
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-4 md:space-y-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
						title: "System Health",
						subtitle: "Realtime infrastructure",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "space-y-2",
							children: [
								{
									i: Database,
									l: "Primary DB",
									v: "Healthy",
									t: "success"
								},
								{
									i: Cpu,
									l: "AI Inference",
									v: "42ms avg",
									t: "info"
								},
								{
									i: Activity,
									l: "Ingestion Queue",
									v: "0 backlog",
									t: "success"
								},
								{
									i: Key,
									l: "Auth Service",
									v: "OK",
									t: "success"
								}
							].map((x) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "panel-inset px-3 py-2.5 flex items-center gap-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(x.i, { className: "w-4 h-4 text-primary" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "flex-1 text-[12.5px]",
										children: x.l
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
										tone: x.t,
										children: x.v
									})
								]
							}, x.l))
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
						title: "Integrations",
						subtitle: "Connected data sources",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "space-y-2",
							children: [
								["CCTNS Registry", true],
								["ICJS Court System", true],
								["Aadhaar Verify", true],
								["Vehicle Registry (VAHAN)", true],
								["Telecom CDR", false]
							].map(([l, on]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "panel-inset px-3 py-2.5 flex items-center gap-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "w-4 h-4 text-secondary" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "flex-1 text-[12.5px]",
										children: l
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
										tone: on ? "success" : "default",
										children: on ? "Connected" : "Off"
									})
								]
							}, l))
						})
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
				title: "Audit Log",
				subtitle: "Last 6 privileged actions",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "space-y-1.5",
					children: [
						"SP Vijay Kumar changed role for Insp. R. Sharma → Investigator · 2h ago",
						"DySP M. Rao exported case C-3418 evidence bundle · 4h ago",
						"System rotated API key for CCTNS integration · 8h ago",
						"SI K. Naidu account suspended by DySP L. Kumar · 1d ago",
						"AI model v4.2 promoted to production by admin · 1d ago",
						"New user provisioned: Insp. B. Rao (Belagavi) · 2d ago"
					].map((l, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "panel-inset px-3 py-2 text-[12px] text-secondary flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "live-dot",
							style: { background: "var(--color-info)" }
						}), l]
					}, i))
				})
			})
		]
	});
}
//#endregion
export { AdminPage as component };
