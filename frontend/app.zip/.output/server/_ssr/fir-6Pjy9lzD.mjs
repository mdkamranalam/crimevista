import { i as __toESM } from "../_runtime.mjs";
import { n as require_jsx_runtime, r as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { F as Eye, L as Ellipsis, M as FileText, R as Download, W as ChevronDown, g as Plus, j as Funnel, m as Search } from "../_libs/lucide-react.mjs";
import { a as Panel, i as PageHeader, n as Btn, o as StatTile, r as Chip, t as AppShell } from "./ui-Bwzm-qoz.mjs";
import { t as api } from "./api-CLd47u8k.mjs";
import { t as IncidentDetailModal } from "./IncidentDetailModal-4wllTAwk.mjs";
import { a as YAxis, l as CartesianGrid, m as Tooltip, o as XAxis, p as ResponsiveContainer, s as Area, t as AreaChart } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/fir-6Pjy9lzD.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var FIRS_FALLBACK = [
	{
		id: "FIR-2026-018472",
		ps: "Koramangala PS",
		type: "Vehicle Theft",
		area: "Bengaluru Urban",
		officer: "Insp. R. Sharma",
		status: "Under Investigation",
		priority: "High",
		time: "2h ago"
	},
	{
		id: "FIR-2026-018471",
		ps: "Mysuru City PS",
		type: "Burglary",
		area: "Mysuru",
		officer: "SI. K. Naidu",
		status: "Filed",
		priority: "Medium",
		time: "3h ago"
	},
	{
		id: "FIR-2026-018470",
		ps: "Hubli East PS",
		type: "Cyber Fraud",
		area: "Dharwad",
		officer: "Insp. A. Iyer",
		status: "Forwarded",
		priority: "High",
		time: "5h ago"
	},
	{
		id: "FIR-2026-018469",
		ps: "Ballari PS",
		type: "Assault",
		area: "Ballari",
		officer: "SI. M. Rao",
		status: "Under Investigation",
		priority: "Critical",
		time: "6h ago"
	},
	{
		id: "FIR-2026-018468",
		ps: "Yeshwanthpur PS",
		type: "Chain Snatching",
		area: "Bengaluru Urban",
		officer: "Insp. P. Menon",
		status: "Closed",
		priority: "Low",
		time: "8h ago"
	},
	{
		id: "FIR-2026-018467",
		ps: "Mangaluru North PS",
		type: "Drug Peddling",
		area: "Dakshina Kannada",
		officer: "Insp. V. Shetty",
		status: "Under Investigation",
		priority: "High",
		time: "10h ago"
	},
	{
		id: "FIR-2026-018466",
		ps: "Shivamogga PS",
		type: "Kidnapping",
		area: "Shivamogga",
		officer: "DySP. L. Kumar",
		status: "Forwarded",
		priority: "Critical",
		time: "12h ago"
	},
	{
		id: "FIR-2026-018465",
		ps: "Tumakuru PS",
		type: "Vehicle Theft",
		area: "Tumakuru",
		officer: "SI. B. Prasad",
		status: "Filed",
		priority: "Medium",
		time: "14h ago"
	}
];
var TREND = Array.from({ length: 30 }, (_, i) => ({
	d: `D${i + 1}`,
	v: 180 + Math.round(Math.sin(i / 3) * 40 + i * 1.5)
}));
var priorityTone = (p) => p === "Critical" ? "danger" : p === "High" ? "warning" : p === "Medium" ? "info" : "success";
var statusTone = (s) => s === "Closed" || s === "Solved" ? "success" : s === "Under Investigation" ? "warning" : s === "Forwarded" ? "info" : "default";
function FirPage() {
	const [firs, setFirs] = (0, import_react.useState)(FIRS_FALLBACK);
	const [totalCount, setTotalCount] = (0, import_react.useState)(18472);
	const [search, setSearch] = (0, import_react.useState)("");
	const [selectedIncident, setSelectedIncident] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		api.getIncidents({
			limit: 12,
			district: search || void 0
		}).then((data) => {
			if (data && data.items && data.items.length > 0) {
				const mapped = data.items.map((it, idx) => ({
					...it,
					id: it.case_number || `FIR-2026-${(18472 - idx).toString().padStart(6, "0")}`,
					ps: it.police_station || "District PS",
					type: it.crime_type || "General Case",
					area: it.district || "Karnataka",
					officer: idx % 2 === 0 ? "Insp. R. Sharma" : "SI. K. Naidu",
					status: it.status || "Under Investigation",
					priority: it.severity || (idx % 3 === 0 ? "High" : "Medium"),
					time: it.date_time ? new Date(it.date_time).toLocaleDateString("en-IN", {
						day: "2-digit",
						month: "short"
					}) : `${idx + 1}h ago`
				}));
				setFirs(mapped);
				if (data.count) setTotalCount(data.count);
			}
		});
	}, [search]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		title: "FIR Intelligence",
		subtitle: "Full database search & status triage",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: "FIR Intelligence",
				description: "Search, filter and triage First Information Reports state-wide",
				actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					variant: "outline",
					icon: Download,
					children: "Export CSV"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					icon: Plus,
					children: "Log New FIR"
				})] })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatTile, {
						label: "Total Indexed FIRs",
						value: totalCount.toLocaleString(),
						hint: "+245 today",
						tone: "info"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatTile, {
						label: "Active Investigations",
						value: `${Math.round(totalCount * .08).toLocaleString()}`,
						hint: "Assigned to IOs",
						tone: "warning"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatTile, {
						label: "Solved Year to Date",
						value: `${Math.round(totalCount * .53).toLocaleString()}`,
						hint: "53.2% clearance rate",
						tone: "success"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatTile, {
						label: "Critical Priority",
						value: `${Math.round(totalCount * .03).toLocaleString()}`,
						hint: "Immediate action",
						tone: "danger"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
				title: "Daily Ingestion Trend",
				subtitle: "State-wide FIR logging rate over 30 days",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "h-[180px]",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AreaChart, {
						data: TREND,
						margin: {
							top: 4,
							right: 8,
							bottom: 0,
							left: -18
						},
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("defs", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("linearGradient", {
								id: "fTr",
								x1: "0",
								y1: "0",
								x2: "0",
								y2: "1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
									offset: "5%",
									stopColor: "var(--color-primary)",
									stopOpacity: .3
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
									offset: "95%",
									stopColor: "var(--color-primary)",
									stopOpacity: 0
								})]
							}) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
								stroke: "oklch(1 0 0 / 0.06)",
								vertical: false
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
								dataKey: "d",
								tick: {
									fontSize: 10,
									fill: "oklch(1 0 0 / 0.5)"
								},
								axisLine: false,
								tickLine: false
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
								tick: {
									fontSize: 10,
									fill: "oklch(1 0 0 / 0.5)"
								},
								axisLine: false,
								tickLine: false
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, { contentStyle: {
								background: "var(--color-navy-elev)",
								border: "1px solid var(--color-hairline)",
								borderRadius: 8,
								fontSize: 11
							} }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
								type: "monotone",
								dataKey: "v",
								stroke: "var(--color-primary)",
								strokeWidth: 2,
								fillOpacity: 1,
								fill: "url(#fTr)"
							})
						]
					}) })
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				title: "FIR Registry",
				subtitle: "Detailed case log with priority sorting",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center gap-2 mb-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative flex-1 min-w-[220px]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-secondary" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								placeholder: "Search district, FIR No., crime type...",
								value: search,
								onChange: (e) => setSearch(e.target.value),
								className: "w-full panel-inset pl-9 pr-3 h-9 text-[12.5px] rounded-md focus:outline-none focus:ring-1 focus:ring-primary/60"
							})]
						}), [
							"Priority",
							"District",
							"Status",
							"Type"
						].map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							className: "panel-inset px-3 h-9 text-[12px] rounded-md flex items-center gap-1.5 hover:text-primary",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Funnel, { className: "w-3.5 h-3.5" }),
								f,
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "w-3.5 h-3.5" })
							]
						}, f))]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "overflow-x-auto -mx-4 md:-mx-5 px-4 md:px-5",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
							className: "w-full text-[12.5px] min-w-[900px]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "text-[10.5px] uppercase tracking-wider text-secondary text-left border-b hairline",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "py-2 pr-3 font-semibold",
										children: "FIR ID"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "py-2 pr-3 font-semibold",
										children: "Type"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "py-2 pr-3 font-semibold",
										children: "Station"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "py-2 pr-3 font-semibold",
										children: "District"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "py-2 pr-3 font-semibold",
										children: "Officer"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "py-2 pr-3 font-semibold",
										children: "Priority"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "py-2 pr-3 font-semibold",
										children: "Status"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "py-2 pr-3 font-semibold",
										children: "Filed"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "py-2 font-semibold text-right",
										children: "Action"
									})
								]
							}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: firs.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "border-b hairline hover:bg-white/[0.05] transition-colors cursor-pointer",
								onClick: () => setSelectedIncident(f),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-2.5 pr-3 font-mono text-primary",
										children: f.id
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
										className: "py-2.5 pr-3 flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "w-3.5 h-3.5 text-secondary" }), f.type]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-2.5 pr-3",
										children: f.ps
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-2.5 pr-3 text-secondary",
										children: f.area
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-2.5 pr-3 text-secondary",
										children: f.officer
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-2.5 pr-3",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
											tone: priorityTone(f.priority),
											children: f.priority
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-2.5 pr-3",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
											tone: statusTone(f.status),
											children: f.status
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-2.5 pr-3 text-secondary font-mono text-[11px]",
										children: f.time
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-2.5 text-right",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "inline-flex items-center gap-1",
											onClick: (e) => e.stopPropagation(),
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												className: "panel-inset w-7 h-7 rounded flex items-center justify-center hover:text-primary",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "w-3.5 h-3.5" })
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												className: "panel-inset w-7 h-7 rounded flex items-center justify-center hover:text-primary",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ellipsis, { className: "w-3.5 h-3.5" })
											})]
										})
									})
								]
							}, f.id)) })]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center justify-between gap-3 mt-4 text-[11.5px] text-secondary",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							"Showing 1–",
							firs.length,
							" of ",
							totalCount.toLocaleString()
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
								variant: "outline",
								children: "Previous"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
								variant: "outline",
								children: "Next"
							})]
						})]
					})
				]
			}),
			selectedIncident && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IncidentDetailModal, {
				incident: selectedIncident,
				onClose: () => setSelectedIncident(null)
			})
		]
	});
}
//#endregion
export { FirPage as component };
