//#region node_modules/.nitro/vite/services/ssr/assets/vidhana-soudha-CCYvDeTj.js
var ksp_logo_default = "/assets/ksp-logo-DgV97Jhx.png";
var vidhana_soudha_default = "/assets/vidhana-soudha-CrJJjxG_.png";
//#endregion
export { vidhana_soudha_default as n, ksp_logo_default as t };
