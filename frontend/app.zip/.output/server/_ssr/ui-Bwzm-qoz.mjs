import { i as __toESM } from "../_runtime.mjs";
import { n as vidhana_soudha_default, t as ksp_logo_default } from "./vidhana-soudha-CCYvDeTj.mjs";
import { n as require_jsx_runtime, r as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { g as Link, l as useRouterState } from "../_libs/@tanstack/react-router+[...].mjs";
import { A as Globe, B as Cpu, E as LayoutDashboard, J as Brain, N as FileSearch, P as FileChartColumn, T as Lock, V as CircleDot, Y as Bell, b as Menu, c as Sparkles, d as ShieldCheck, f as ShieldAlert, h as Radio, m as Search, n as X, p as Settings, v as Network, w as LogOut, x as Map, y as Moon, z as Database } from "../_libs/lucide-react.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ui-Bwzm-qoz.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var NAV = [
	{
		icon: LayoutDashboard,
		label: "Intelligence Brief",
		to: "/"
	},
	{
		icon: FileSearch,
		label: "FIR Intelligence",
		to: "/fir"
	},
	{
		icon: Map,
		label: "Crime Heatmap",
		to: "/heatmap"
	},
	{
		icon: Network,
		label: "Relationship Intelligence",
		to: "/relationships"
	},
	{
		icon: Brain,
		label: "Predictive Analytics",
		to: "/predictive"
	},
	{
		icon: ShieldAlert,
		label: "Alerts & Notifications",
		to: "/alerts",
		badge: "12"
	},
	{
		icon: FileChartColumn,
		label: "Reports & Analytics",
		to: "/reports"
	},
	{
		icon: ShieldCheck,
		label: "Case Management",
		to: "/cases"
	},
	{
		icon: Settings,
		label: "Administration",
		to: "/admin"
	}
];
function Sidebar({ mobileOpen = false, onClose }) {
	const path = useRouterState({ select: (s) => s.location.pathname });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [mobileOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "lg:hidden fixed inset-0 z-40 bg-black/60 backdrop-blur-sm",
		onClick: onClose
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
		className: cn("flex w-[280px] shrink-0 flex-col bg-sidebar border-r hairline min-h-screen", "fixed inset-y-0 left-0 z-50 transition-transform duration-200 lg:sticky lg:top-0 lg:translate-x-0", mobileOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0"),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-3 px-5 py-5 border-b hairline",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "w-12 h-12 rounded-lg overflow-hidden border border-primary/30 bg-white/5 flex items-center justify-center",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: ksp_logo_default,
							alt: "CrimeVista Logo",
							className: "w-full h-full object-contain p-1"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "font-bold text-[18px] tracking-tight leading-tight truncate",
								children: ["Crime", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-primary",
									children: "Vista"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-[10px] uppercase tracking-[0.18em] text-secondary leading-tight mt-0.5",
								children: "AI Crime Intelligence Platform"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-[10px] text-secondary/70 leading-tight",
								children: "Government of Karnataka"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "lg:hidden text-secondary hover:text-foreground",
						onClick: onClose,
						"aria-label": "Close menu",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "w-5 h-5" })
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "flex-1 px-3 py-4 space-y-1 overflow-y-auto scrollbar-thin",
				children: NAV.map((item) => {
					const active = path === item.to;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: item.to,
						onClick: onClose,
						className: cn("group flex items-center gap-3 px-3 py-2.5 rounded-md text-[13.5px] font-medium transition-all", active ? "bg-primary text-primary-foreground shadow-[var(--shadow-gold)]" : "text-sidebar-foreground/85 hover:bg-sidebar-accent hover:translate-x-0.5"),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(item.icon, { className: "w-[18px] h-[18px] shrink-0" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "flex-1 truncate",
								children: item.label
							}),
							item.badge && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: cn("text-[10px] font-mono px-1.5 py-0.5 rounded", active ? "bg-primary-foreground/15 text-primary-foreground" : "bg-destructive/25 text-destructive-foreground"),
								children: item.badge
							})
						]
					}, item.label);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "border-t hairline p-3 space-y-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "panel-inset flex items-center gap-2 px-3 py-2 text-[11.5px]",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							className: "flex-1 bg-transparent outline-none text-secondary",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									className: "bg-navy-card",
									children: "🌐 English"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									className: "bg-navy-card",
									children: "ಕನ್ನಡ"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									className: "bg-navy-card",
									children: "हिन्दी"
								})
							]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "panel-inset px-3 py-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2 text-[11.5px] font-semibold",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleDot, { className: "w-3.5 h-3.5 text-primary" }), "Secure. Intelligent. Effective."]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-3 flex justify-center",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: vidhana_soudha_default,
									alt: "Vidhana Soudha",
									className: "w-full max-w-[180px] object-contain opacity-30"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-[10.5px] text-secondary mt-2 text-center",
								children: "Building a Safer Karnataka with AI"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/login",
						className: "w-full flex items-center gap-2 px-3 py-2 text-[12px] text-secondary hover:text-foreground rounded-md hover:bg-sidebar-accent transition-colors",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, { className: "w-4 h-4" }),
							"Logout",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "ml-auto font-mono text-[10px] opacity-60",
								children: "v2.4.1"
							})
						]
					})
				]
			})
		]
	})] });
}
function TopBar({ title = "Good Morning, SP Vijay Kumar 👋", subtitle = "Here's your intelligence brief for today", onMenuClick }) {
	const [now, setNow] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		setNow((/* @__PURE__ */ new Date()).toLocaleDateString("en-IN", {
			weekday: "short",
			day: "2-digit",
			month: "short",
			year: "numeric"
		}));
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "sticky top-0 z-20 h-[64px] md:h-[72px] bg-navy/90 backdrop-blur-md border-b hairline flex items-center gap-3 md:gap-4 px-3 md:px-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				className: "lg:hidden text-secondary hover:text-foreground shrink-0",
				onClick: onMenuClick,
				"aria-label": "Open menu",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "w-5 h-5" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0 hidden sm:block",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-[15px] md:text-[17px] font-semibold leading-tight truncate",
					children: title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-[11px] md:text-[11.5px] text-secondary leading-tight mt-0.5 truncate",
					children: [subtitle, now && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "hidden md:inline",
						children: [" · ", now]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex-1 max-w-[520px] mx-auto min-w-0",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-secondary" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "text",
							placeholder: "Search FIR, Case, Person...",
							className: "w-full bg-navy-card border hairline rounded-md pl-9 pr-3 md:pr-14 h-9 md:h-10 text-[13px] placeholder:text-secondary/70 focus:outline-none focus:ring-1 focus:ring-primary/60 focus:border-primary/60 transition"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("kbd", {
							className: "hidden md:block absolute right-2.5 top-1/2 -translate-y-1/2 font-mono text-[10px] px-1.5 py-0.5 rounded panel-inset text-secondary",
							children: "Ctrl + K"
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "hidden 2xl:flex items-center gap-3 text-[11px]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusChip, {
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "live-dot" }),
						label: "LIVE"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusChip, {
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Database, { className: "w-3.5 h-3.5 text-success" }),
						label: "Backend",
						value: "Healthy"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusChip, {
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cpu, { className: "w-3.5 h-3.5 text-info" }),
						label: "AI",
						value: "Online"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				className: "hidden sm:flex w-9 h-9 rounded-md panel-inset items-center justify-center hover:text-primary transition-colors shrink-0",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Moon, { className: "w-4 h-4" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				className: "w-9 h-9 rounded-md panel-inset flex items-center justify-center relative hover:text-primary transition-colors shrink-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bell, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "absolute -top-1 -right-1 min-w-[18px] h-[18px] px-1 rounded-full bg-destructive text-[10px] font-mono font-semibold flex items-center justify-center",
					children: "7"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "hidden md:flex items-center gap-3 pl-3 border-l hairline shrink-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-right",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-[13px] font-semibold leading-tight",
						children: "SP Vijay Kumar"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-[10.5px] text-secondary leading-tight",
						children: "Karnataka Police"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "w-10 h-10 rounded-full bg-gradient-to-br from-primary/70 to-primary/30 border border-primary/50 flex items-center justify-center font-bold text-primary-foreground text-sm",
					children: "VK"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "md:hidden w-9 h-9 rounded-full bg-gradient-to-br from-primary/70 to-primary/30 border border-primary/50 flex items-center justify-center font-bold text-primary-foreground text-xs shrink-0",
				children: "VK"
			})
		]
	});
}
function StatusChip({ icon, label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-1.5 px-2.5 py-1.5 rounded-md panel-inset",
		children: [
			icon,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "uppercase tracking-wider text-secondary text-[10px] font-semibold",
				children: label
			}),
			value && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-foreground font-medium",
				children: value
			})
		]
	});
}
var ITEMS = [
	{
		icon: Globe,
		title: "Multi-language Support",
		body: "22+ Indian Official Languages"
	},
	{
		icon: ShieldCheck,
		title: "Role Based Access",
		body: "Secure access for different roles"
	},
	{
		icon: Lock,
		title: "Secure & Compliant",
		body: "All data is encrypted and secure"
	},
	{
		icon: Radio,
		title: "Real-time Intelligence",
		body: "Live updates and instant alerts"
	},
	{
		icon: Sparkles,
		title: "AI Powered Insights",
		body: "Smart predictions and analytics"
	}
];
function Footer() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
		className: "mt-6 panel px-6 py-5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid grid-cols-2 md:grid-cols-3 xl:grid-cols-5 gap-5",
			children: ITEMS.map((it) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "w-9 h-9 rounded-md gold-chip flex items-center justify-center shrink-0",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(it.icon, { className: "w-4 h-4" })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-[12.5px] font-semibold",
					children: it.title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-[11px] text-secondary",
					children: it.body
				})] })]
			}, it.title))
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-5 pt-4 border-t hairline flex flex-wrap items-center justify-between gap-2 text-[11px] text-secondary",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				"© ",
				(/* @__PURE__ */ new Date()).getFullYear(),
				" Karnataka State Police · CrimeVista Platform"
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "font-mono",
				children: "Build v2.4.1 · Region: IN-KA · Uptime 99.98%"
			})]
		})]
	});
}
function AppShell({ title, subtitle, children }) {
	const [open, setOpen] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen flex bg-background text-foreground",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sidebar, {
			mobileOpen: open,
			onClose: () => setOpen(false)
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex-1 flex flex-col min-w-0",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TopBar, {
				title,
				subtitle,
				onMenuClick: () => setOpen(true)
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "flex-1 px-3 sm:px-4 md:px-6 py-4 md:py-5 max-w-[1920px] w-full mx-auto space-y-4 md:space-y-5",
				children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Footer, {})]
			})]
		})]
	});
}
function PageHeader({ title, description, actions }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid grid-cols-[minmax(0,1fr)_auto] items-start gap-3 md:gap-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-w-0",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-[20px] md:text-[24px] font-bold tracking-tight truncate",
				children: title
			}), description && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[12px] md:text-[13px] text-secondary mt-1",
				children: description
			})]
		}), actions && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex items-center gap-2 shrink-0",
			children: actions
		})]
	});
}
function Panel({ children, className, title, subtitle, action }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: cn("panel p-4 md:p-5", className),
		children: [(title || action) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-start justify-between gap-3 mb-3 md:mb-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0",
				children: [title && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "text-[14px] md:text-[15px] font-semibold truncate",
					children: title
				}), subtitle && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[11.5px] text-secondary mt-0.5",
					children: subtitle
				})]
			}), action && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "shrink-0",
				children: action
			})]
		}), children]
	});
}
function Chip({ children, tone = "default", className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("inline-flex items-center gap-1 text-[10.5px] font-semibold px-2 py-0.5 rounded border", {
			default: "bg-white/5 text-secondary border-white/10",
			gold: "bg-primary/15 text-primary border-primary/30",
			success: "bg-success/15 text-success border-success/30",
			warning: "bg-warning/15 text-warning border-warning/30",
			danger: "bg-destructive/15 text-destructive border-destructive/30",
			info: "bg-info/15 text-info border-info/30"
		}[tone], className),
		children
	});
}
function Btn({ children, variant = "primary", icon: Icon, className, onClick, type }) {
	const v = {
		primary: "bg-primary text-primary-foreground hover:brightness-110 shadow-[var(--shadow-gold)]",
		ghost: "text-secondary hover:text-foreground hover:bg-white/5",
		outline: "panel-inset hover:border-primary/40 hover:text-primary"
	}[variant];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: type ?? "button",
		onClick,
		className: cn("inline-flex items-center gap-1.5 px-3 py-2 rounded-md text-[12.5px] font-semibold transition-all", v, className),
		children: [Icon && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "w-4 h-4" }), children]
	});
}
function StatTile({ label, value, hint, tone = "gold" }) {
	const dot = {
		gold: "bg-primary",
		info: "bg-info",
		success: "bg-success",
		warning: "bg-warning",
		danger: "bg-destructive"
	}[tone];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "panel-inset px-4 py-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2 text-[10.5px] uppercase tracking-wider text-secondary font-semibold",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("w-1.5 h-1.5 rounded-full", dot) }), label]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-1.5 text-[22px] font-mono font-bold tracking-tight",
				children: value
			}),
			hint && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-[11px] text-secondary mt-0.5",
				children: hint
			})
		]
	});
}
//#endregion
export { Panel as a, PageHeader as i, Btn as n, StatTile as o, Chip as r, cn as s, AppShell as t };
