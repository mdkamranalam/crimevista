import { i as __toESM } from "../_runtime.mjs";
import { n as require_jsx_runtime, r as require_react, t as QueryClientProvider } from "../_libs/react+tanstack__react-query.mjs";
import { c as HeadContent, d as createRouter, f as Outlet, g as Link, h as createRootRouteWithContext, m as createFileRoute, p as lazyRouteComponent, s as Scripts, v as useRouter } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as Route$11 } from "./district-DHIVk6pD.mjs";
import { t as QueryClient } from "../_libs/tanstack__query-core.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-DgpqqNio.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var styles_default = "/assets/styles-Bfq1S4kv.css";
function reportLovableError(error, context = {}) {
	if (typeof window === "undefined") return;
	window.__lovableEvents?.captureException?.(error, {
		source: "react_error_boundary",
		route: window.location.pathname,
		...context
	}, {
		mechanism: "react_error_boundary",
		handled: false,
		severity: "error"
	});
}
function NotFoundComponent() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-7xl font-bold text-foreground",
					children: "404"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-4 text-xl font-semibold text-foreground",
					children: "Page not found"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "The page you're looking for doesn't exist or has been moved."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Go home"
					})
				})
			]
		})
	});
}
function ErrorComponent({ error, reset }) {
	console.error(error);
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		reportLovableError(error, { boundary: "tanstack_root_error_component" });
	}, [error]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-xl font-semibold tracking-tight text-foreground",
					children: "This page didn't load"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "Something went wrong on our end. You can try refreshing or head back home."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex flex-wrap justify-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => {
							router.invalidate();
							reset();
						},
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Try again"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "/",
						className: "inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent",
						children: "Go home"
					})]
				})
			]
		})
	});
}
var Route$10 = createRootRouteWithContext()({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: "CrimeVista — AI Crime Intelligence Platform | Karnataka Police" },
			{
				name: "description",
				content: "CrimeVista is the AI-powered crime intelligence command center for the Government of Karnataka, unifying FIR data, heatmaps, predictive analytics and relationship intelligence."
			},
			{
				name: "author",
				content: "Government of Karnataka"
			},
			{
				property: "og:title",
				content: "CrimeVista — AI Crime Intelligence Platform | Karnataka Police"
			},
			{
				property: "og:description",
				content: "CrimeVista is the AI-powered crime intelligence command center for the Government of Karnataka, unifying FIR data, heatmaps, predictive analytics and relationship intelligence."
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				name: "twitter:card",
				content: "summary_large_image"
			},
			{
				name: "twitter:title",
				content: "CrimeVista — AI Crime Intelligence Platform | Karnataka Police"
			},
			{
				name: "twitter:description",
				content: "CrimeVista is the AI-powered crime intelligence command center for the Government of Karnataka, unifying FIR data, heatmaps, predictive analytics and relationship intelligence."
			},
			{
				property: "og:image",
				content: "https://pub-bb2e103a32db4e198524a2e9ed8f35b4.r2.dev/27a0f276-c0ea-40f2-96dd-d635cc609f28/id-preview-8411e1d1--5b5f646b-349b-46c0-9a2a-514fc7e95358.lovable.app-1784141233642.png"
			},
			{
				name: "twitter:image",
				content: "https://pub-bb2e103a32db4e198524a2e9ed8f35b4.r2.dev/27a0f276-c0ea-40f2-96dd-d635cc609f28/id-preview-8411e1d1--5b5f646b-349b-46c0-9a2a-514fc7e95358.lovable.app-1784141233642.png"
			}
		],
		links: [
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "icon",
				href: "/favicon.ico",
				type: "image/x-icon"
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=JetBrains+Mono:wght@400;500;600;700&display=swap"
			}
		]
	}),
	shellComponent: RootShell,
	component: RootComponent,
	notFoundComponent: NotFoundComponent,
	errorComponent: ErrorComponent
});
function RootShell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})] })]
	});
}
function RootComponent() {
	const { queryClient } = Route$10.useRouteContext();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueryClientProvider, {
		client: queryClient,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {})
	});
}
var $$splitComponentImporter$9 = () => import("./reports-BayvoylK.mjs");
var Route$9 = createFileRoute("/reports")({
	component: lazyRouteComponent($$splitComponentImporter$9, "component"),
	head: () => ({ meta: [{ title: "Reports & Analytics — CrimeVista" }, {
		name: "description",
		content: "Analytical reports and exports across Karnataka."
	}] })
});
var $$splitComponentImporter$8 = () => import("./relationships-BOLflrJs.mjs");
var Route$8 = createFileRoute("/relationships")({
	component: lazyRouteComponent($$splitComponentImporter$8, "component"),
	head: () => ({ meta: [{ title: "Relationship Intelligence — CrimeVista" }, {
		name: "description",
		content: "Graph analytics of persons, gangs and case relationships."
	}] })
});
var $$splitComponentImporter$7 = () => import("./predictive-BAH33Qtd.mjs");
var Route$7 = createFileRoute("/predictive")({
	component: lazyRouteComponent($$splitComponentImporter$7, "component"),
	head: () => ({ meta: [{ title: "Predictive Analytics — CrimeVista" }, {
		name: "description",
		content: "AI-driven crime forecasting and hotspot prediction."
	}] })
});
var $$splitComponentImporter$6 = () => import("./login-CVF93hiN.mjs");
var Route$6 = createFileRoute("/login")({ component: lazyRouteComponent($$splitComponentImporter$6, "component") });
var $$splitComponentImporter$5 = () => import("./heatmap-v3wRDn3v.mjs");
var Route$5 = createFileRoute("/heatmap")({
	component: lazyRouteComponent($$splitComponentImporter$5, "component"),
	head: () => ({ meta: [{ title: "Crime Heatmap — CrimeVista" }, {
		name: "description",
		content: "Live geographic heatmap of crime density across Karnataka."
	}] })
});
var $$splitComponentImporter$4 = () => import("./fir-6Pjy9lzD.mjs");
var Route$4 = createFileRoute("/fir")({
	component: lazyRouteComponent($$splitComponentImporter$4, "component"),
	head: () => ({ meta: [{ title: "FIR Intelligence — CrimeVista" }, {
		name: "description",
		content: "Search, triage and analyse First Information Reports across Karnataka."
	}] })
});
var $$splitComponentImporter$3 = () => import("./cases-XN9B6WhJ.mjs");
var Route$3 = createFileRoute("/cases")({
	component: lazyRouteComponent($$splitComponentImporter$3, "component"),
	head: () => ({ meta: [{ title: "Case Management — CrimeVista" }, {
		name: "description",
		content: "Track investigations, assignments and case progress."
	}] })
});
var $$splitComponentImporter$2 = () => import("./alerts-6RwCnpBV.mjs");
var Route$2 = createFileRoute("/alerts")({
	component: lazyRouteComponent($$splitComponentImporter$2, "component"),
	head: () => ({ meta: [{ title: "Alerts & Notifications — CrimeVista" }, {
		name: "description",
		content: "Emergency alerts, escalations and notifications."
	}] })
});
var $$splitComponentImporter$1 = () => import("./admin-CzMsrmdc.mjs");
var Route$1 = createFileRoute("/admin")({
	component: lazyRouteComponent($$splitComponentImporter$1, "component"),
	head: () => ({ meta: [{ title: "Administration — CrimeVista" }, {
		name: "description",
		content: "User roles, permissions and system administration."
	}] })
});
var $$splitComponentImporter = () => import("./routes-CqmvjGuf.mjs");
var Route = createFileRoute("/")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
var ReportsRoute = Route$9.update({
	id: "/reports",
	path: "/reports",
	getParentRoute: () => Route$10
});
var RelationshipsRoute = Route$8.update({
	id: "/relationships",
	path: "/relationships",
	getParentRoute: () => Route$10
});
var PredictiveRoute = Route$7.update({
	id: "/predictive",
	path: "/predictive",
	getParentRoute: () => Route$10
});
var LoginRoute = Route$6.update({
	id: "/login",
	path: "/login",
	getParentRoute: () => Route$10
});
var HeatmapRoute = Route$5.update({
	id: "/heatmap",
	path: "/heatmap",
	getParentRoute: () => Route$10
});
var FirRoute = Route$4.update({
	id: "/fir",
	path: "/fir",
	getParentRoute: () => Route$10
});
var DistrictRoute = Route$11.update({
	id: "/district",
	path: "/district",
	getParentRoute: () => Route$10
});
var CasesRoute = Route$3.update({
	id: "/cases",
	path: "/cases",
	getParentRoute: () => Route$10
});
var AlertsRoute = Route$2.update({
	id: "/alerts",
	path: "/alerts",
	getParentRoute: () => Route$10
});
var AdminRoute = Route$1.update({
	id: "/admin",
	path: "/admin",
	getParentRoute: () => Route$10
});
var rootRouteChildren = {
	IndexRoute: Route.update({
		id: "/",
		path: "/",
		getParentRoute: () => Route$10
	}),
	AdminRoute,
	AlertsRoute,
	CasesRoute,
	DistrictRoute,
	FirRoute,
	HeatmapRoute,
	LoginRoute,
	PredictiveRoute,
	RelationshipsRoute,
	ReportsRoute
};
var routeTree = Route$10._addFileChildren(rootRouteChildren)._addFileTypes();
var getRouter = () => {
	return createRouter({
		routeTree,
		context: { queryClient: new QueryClient() },
		scrollRestoration: true,
		defaultPreloadStaleTime: 0
	});
};
//#endregion
export { getRouter };
