import { i as __toESM } from "../_runtime.mjs";
import { n as require_jsx_runtime, r as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { C as MapPin, K as Calendar, M as FileText, a as TriangleAlert, n as X, v as Network } from "../_libs/lucide-react.mjs";
import { n as Btn, r as Chip } from "./ui-Bwzm-qoz.mjs";
import { t as api } from "./api-CLd47u8k.mjs";
import { n as Skeleton } from "./Skeleton-D98sCtxl.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/IncidentDetailModal-4wllTAwk.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function IncidentDetailModal({ incident, onClose }) {
	const [network, setNetwork] = (0, import_react.useState)(null);
	const [loading, setLoading] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (incident) {
			setLoading(true);
			setNetwork(null);
			const entityId = incident.case_number || incident.id;
			api.getNetworkAnalysis(entityId).then((data) => {
				setNetwork(data);
				setLoading(false);
			});
		}
	}, [incident]);
	if (!incident) return null;
	const priorityTone = (p) => p === "Critical" ? "danger" : p === "High" ? "warning" : p === "Medium" ? "info" : "success";
	const statusTone = (s) => s === "Closed" || s === "Solved" ? "success" : s === "Under Investigation" ? "warning" : s === "Forwarded" ? "info" : "default";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "panel w-full max-w-3xl max-h-[90vh] overflow-hidden flex flex-col shadow-2xl ring-1 ring-white/10 animate-in fade-in zoom-in-95 duration-200",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start justify-between p-4 md:p-5 border-b border-white/10 bg-white/[0.02]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "text-lg font-semibold tracking-tight text-foreground",
									children: incident.case_number || "Unknown Case"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
									tone: priorityTone(incident.severity),
									children: incident.severity
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
									tone: statusTone(incident.status),
									children: incident.status
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm text-secondary flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "w-3.5 h-3.5" }), incident.crime_type]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: onClose,
						className: "p-1.5 rounded-md hover:bg-white/10 text-secondary hover:text-white transition-colors",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "w-5 h-5" })
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex-1 overflow-y-auto p-4 md:p-5 space-y-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 md:grid-cols-4 gap-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "panel-inset p-3 space-y-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-[11px] uppercase tracking-wider text-secondary flex items-center gap-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "w-3.5 h-3.5" }), " District"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-sm font-medium",
									children: incident.district
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "panel-inset p-3 space-y-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-[11px] uppercase tracking-wider text-secondary flex items-center gap-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "w-3.5 h-3.5" }), " Station"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-sm font-medium",
									children: incident.police_station || "Unknown"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "panel-inset p-3 space-y-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-[11px] uppercase tracking-wider text-secondary flex items-center gap-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calendar, { className: "w-3.5 h-3.5" }), " Date & Time"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-sm font-medium",
									children: incident.date_time ? new Date(incident.date_time).toLocaleString("en-IN", {
										dateStyle: "medium",
										timeStyle: "short"
									}) : "N/A"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "panel-inset p-3 space-y-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-[11px] uppercase tracking-wider text-secondary flex items-center gap-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "w-3.5 h-3.5" }), " Location"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-sm font-medium truncate",
									title: incident.location_name,
									children: incident.location_name || "Unknown"
								})]
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
							className: "text-[13.5px] font-semibold flex items-center gap-2 text-primary",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Network, { className: "w-4 h-4" }), " Connected Network Entities"]
						}), loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-12 w-full" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-12 w-full" })]
						}) : network && network.nodes.length > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "panel-inset p-4",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "space-y-3",
								children: network.edges.map((edge, idx) => {
									const sourceNode = network.nodes.find((n) => n.id === edge.source);
									const targetNode = network.nodes.find((n) => n.id === edge.target);
									if (!sourceNode || !targetNode) return null;
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
										className: "flex items-center gap-2 text-sm",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-semibold px-2 py-0.5 rounded bg-white/5",
												children: sourceNode.label
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-[10px] text-secondary uppercase tracking-widest px-2",
												children: edge.type.replace(/_/g, " ")
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-semibold px-2 py-0.5 rounded bg-white/5",
												children: targetNode.label
											})
										]
									}, idx);
								})
							})
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "panel-inset p-4 text-center text-sm text-secondary",
							children: "No advanced network connections found for this incident."
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "p-4 md:p-5 border-t border-white/10 bg-white/[0.01] flex items-center justify-end gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
						variant: "outline",
						onClick: onClose,
						children: "Close"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
						variant: "primary",
						children: "View Full Case File"
					})]
				})
			]
		})
	});
}
//#endregion
export { IncidentDetailModal as t };
