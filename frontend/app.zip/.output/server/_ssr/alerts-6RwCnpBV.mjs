import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { G as Check, Y as Bell, a as TriangleAlert, f as ShieldAlert, j as Funnel } from "../_libs/lucide-react.mjs";
import { a as Panel, i as PageHeader, n as Btn, o as StatTile, r as Chip, t as AppShell } from "./ui-Bwzm-qoz.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/alerts-6RwCnpBV.js
var import_jsx_runtime = require_jsx_runtime();
var ALERTS = [
	{
		id: "AL-9821",
		title: "Armed robbery reported — Koramangala PS",
		time: "2 min ago",
		sev: "Critical",
		ack: false
	},
	{
		id: "AL-9820",
		title: "Missing minor — Mysuru City",
		time: "18 min ago",
		sev: "High",
		ack: false
	},
	{
		id: "AL-9819",
		title: "AI hotspot: Vehicle theft cluster in Yeshwanthpur",
		time: "42 min ago",
		sev: "High",
		ack: true
	},
	{
		id: "AL-9818",
		title: "Suspicious activity flagged — Ballari checkpoint",
		time: "1h ago",
		sev: "Medium",
		ack: true
	},
	{
		id: "AL-9817",
		title: "Cyber fraud spike detected — 5 FIRs correlated",
		time: "2h ago",
		sev: "High",
		ack: false
	},
	{
		id: "AL-9816",
		title: "Convict movement alert — Manoj T. sighted",
		time: "3h ago",
		sev: "Critical",
		ack: false
	},
	{
		id: "AL-9815",
		title: "System notice — model v4.2 retrained successfully",
		time: "5h ago",
		sev: "Low",
		ack: true
	}
];
var sevTone = (s) => s === "Critical" ? "danger" : s === "High" ? "warning" : s === "Medium" ? "info" : "success";
function AlertsPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		title: "Alerts & Notifications",
		subtitle: "Realtime escalations",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: "Alerts & Notifications",
				description: "12 active · 3 critical · auto-triaged by AI",
				actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					variant: "outline",
					icon: Funnel,
					children: "Filter"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					icon: Check,
					children: "Acknowledge All"
				})] })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatTile, {
						label: "Critical",
						value: "3",
						tone: "danger",
						hint: "Immediate"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatTile, {
						label: "High",
						value: "9",
						tone: "warning",
						hint: "Under review"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatTile, {
						label: "Acknowledged (24h)",
						value: "47",
						tone: "success"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatTile, {
						label: "Avg Response",
						value: "4m 12s",
						tone: "info"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-1 xl:grid-cols-[1fr_320px] gap-4 md:gap-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
					title: "Live Alert Stream",
					subtitle: "Newest first · realtime",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "space-y-2",
						children: ALERTS.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: `panel-inset px-4 py-3 flex items-start gap-3 ${!a.ack ? "border-l-2 border-l-destructive" : ""}`,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: `w-8 h-8 rounded-md flex items-center justify-center ${a.sev === "Critical" ? "bg-destructive/15 text-destructive" : a.sev === "High" ? "bg-warning/15 text-warning" : "bg-info/15 text-info"}`,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldAlert, { className: "w-4 h-4" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex-1 min-w-0",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-2 flex-wrap",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "font-mono text-[11px] text-primary",
													children: a.id
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
													tone: sevTone(a.sev),
													children: a.sev
												}),
												a.ack && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
													tone: "success",
													children: "Acknowledged"
												})
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-[13px] font-medium mt-0.5",
											children: a.title
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-[11px] text-secondary mt-0.5",
											children: a.time
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-1.5 shrink-0",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
										variant: "outline",
										children: "View"
									}), !a.ack && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
										icon: Check,
										children: "Ack"
									})]
								})
							]
						}, a.id))
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
					title: "Notification Preferences",
					subtitle: "Delivery channels",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "space-y-2",
						children: [
							["SMS to duty officer", true],
							["Push notifications", true],
							["Email digest (hourly)", false],
							["WhatsApp escalation", true],
							["Radio dispatch", false]
						].map(([l, on]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "panel-inset px-3 py-2.5 flex items-center gap-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bell, { className: "w-4 h-4 text-secondary" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "flex-1 text-[12.5px]",
									children: l
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "relative inline-flex cursor-pointer",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "checkbox",
											defaultChecked: on,
											className: "peer sr-only"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "w-8 h-4 bg-white/10 rounded-full peer-checked:bg-primary transition-colors" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute left-0.5 top-0.5 w-3 h-3 bg-white rounded-full peer-checked:translate-x-4 transition-transform" })
									]
								})
							]
						}, l))
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 panel-inset p-3 flex items-start gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "w-4 h-4 text-warning mt-0.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-[11.5px] text-secondary",
							children: "Critical alerts always bypass Do Not Disturb."
						})]
					})]
				})]
			})
		]
	});
}
//#endregion
export { AlertsPage as component };
