import { i as __toESM } from "../_runtime.mjs";
import { n as require_jsx_runtime, r as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { a as Panel, i as PageHeader, o as StatTile, t as AppShell } from "./ui-Bwzm-qoz.mjs";
import { t as api } from "./api-CLd47u8k.mjs";
import { t as Route } from "./district-DHIVk6pD.mjs";
import { t as HeatmapPanel } from "./HeatmapPanel-DlMF_nZX.mjs";
import { a as YAxis, l as CartesianGrid, m as Tooltip, o as XAxis, p as ResponsiveContainer, s as Area, t as AreaChart } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/district-B_hyJSvm.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function DistrictPage() {
	const { name } = Route.useSearch();
	const [districtData, setDistrictData] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		api.getRiskScores().then((data) => {
			const found = data.items.find((d) => d.district.toLowerCase() === name.toLowerCase());
			if (found) setDistrictData(found);
		});
	}, [name]);
	const TREND = Array.from({ length: 30 }, (_, i) => ({
		d: `Day ${i + 1}`,
		v: 50 + Math.round(Math.sin(i / 3) * 15 + i * .5)
	}));
	const toneForRisk = (risk) => risk === "High Risk" ? "danger" : risk === "Medium Risk" ? "warning" : "success";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		title: `${name} Overview`,
		subtitle: "District level crime trends and analytics",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: `${name} Overview`,
				description: districtData?.reason || "Fetching district performance data..."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatTile, {
						label: "Total Incidents",
						value: districtData ? districtData.incident_count.toLocaleString() : "...",
						tone: "info"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatTile, {
						label: "Risk Assessment",
						value: districtData?.risk_category || "...",
						tone: districtData ? toneForRisk(districtData.risk_category) : "default"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatTile, {
						label: "Active Hotspots",
						value: "3",
						tone: "warning"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatTile, {
						label: "Clearance Rate",
						value: "42%",
						tone: "success"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
				title: "30-Day Crime Volume Trend",
				subtitle: `Incident logging rate for ${name}`,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "h-[240px]",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AreaChart, {
						data: TREND,
						margin: {
							top: 10,
							right: 10,
							bottom: 0,
							left: -20
						},
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("defs", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("linearGradient", {
								id: "colorTrend",
								x1: "0",
								y1: "0",
								x2: "0",
								y2: "1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
									offset: "5%",
									stopColor: "var(--color-primary)",
									stopOpacity: .3
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
									offset: "95%",
									stopColor: "var(--color-primary)",
									stopOpacity: 0
								})]
							}) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
								stroke: "oklch(1 0 0 / 0.05)",
								vertical: false
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
								dataKey: "d",
								tick: {
									fontSize: 11,
									fill: "oklch(1 0 0 / 0.5)"
								},
								axisLine: false,
								tickLine: false
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
								tick: {
									fontSize: 11,
									fill: "oklch(1 0 0 / 0.5)"
								},
								axisLine: false,
								tickLine: false
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, { contentStyle: {
								background: "var(--color-navy-elev)",
								border: "1px solid var(--color-hairline)",
								borderRadius: 8,
								fontSize: 12
							} }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
								type: "monotone",
								dataKey: "v",
								stroke: "var(--color-primary)",
								strokeWidth: 2,
								fillOpacity: 1,
								fill: "url(#colorTrend)"
							})
						]
					}) })
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-1 gap-4 md:gap-5 mt-4 md:mt-5",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeatmapPanel, {})
			})
		]
	});
}
//#endregion
export { DistrictPage as component };
