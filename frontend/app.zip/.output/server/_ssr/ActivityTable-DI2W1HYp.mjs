import { i as __toESM } from "../_runtime.mjs";
import { n as require_jsx_runtime, r as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { R as Download, l as SlidersHorizontal, m as Search } from "../_libs/lucide-react.mjs";
import { t as api } from "./api-CLd47u8k.mjs";
import { t as IncidentDetailModal } from "./IncidentDetailModal-4wllTAwk.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ActivityTable-DI2W1HYp.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ActivityTable() {
	const [items, setItems] = (0, import_react.useState)([]);
	const [totalCount, setTotalCount] = (0, import_react.useState)(18472);
	const [search, setSearch] = (0, import_react.useState)("");
	const [selectedIncident, setSelectedIncident] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		api.getIncidents({
			limit: 8,
			district: search || void 0
		}).then((data) => {
			if (data && data.items) {
				setItems(data.items);
				setTotalCount(data.count || 18472);
			}
		});
	}, [search]);
	const toneForStatus = (status) => {
		const s = (status || "").toLowerCase();
		if (s.includes("solved") || s.includes("closed")) return "text-success bg-success/15";
		if (s.includes("investigation")) return "text-warning bg-warning/15";
		return "text-info bg-info/15";
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "panel p-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-3 mb-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-[15px] font-semibold",
						children: "Recent FIR Activity"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11.5px] text-secondary mt-0.5",
						children: "Live feed from all Karnataka district stations"
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "flex-1" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-secondary" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							placeholder: "Search district or police station...",
							value: search,
							onChange: (e) => setSearch(e.target.value),
							className: "bg-navy-card border hairline rounded-md h-9 pl-8 pr-3 text-[12px] w-[240px] placeholder:text-secondary/70 focus:outline-none focus:ring-1 focus:ring-primary/60"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						className: "h-9 px-3 panel-inset text-[12px] flex items-center gap-1.5 hover:text-primary",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SlidersHorizontal, { className: "w-3.5 h-3.5" }), " Filters"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						className: "h-9 px-3 gold-chip rounded-md text-[12px] font-semibold flex items-center gap-1.5 hover:brightness-110",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "w-3.5 h-3.5" }), " Export"]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "overflow-x-auto scrollbar-thin",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full text-[12.5px] min-w-[720px]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "text-left text-[10.5px] uppercase tracking-wider text-secondary border-b hairline",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "py-2.5 pr-3 font-semibold",
								children: "FIR No."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "py-2.5 pr-3 font-semibold",
								children: "Date"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "py-2.5 pr-3 font-semibold",
								children: "Crime Type"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "py-2.5 pr-3 font-semibold",
								children: "Location"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "py-2.5 pr-3 font-semibold",
								children: "Status"
							})
						]
					}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: items.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						onClick: () => setSelectedIncident(r),
						className: "border-b hairline last:border-b-0 hover:bg-white/[0.05] transition-colors cursor-pointer",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-3 pr-3 font-mono text-[11.5px]",
								children: r.case_number || r.id.slice(0, 8)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-3 pr-3 text-secondary",
								children: r.date_time ? new Date(r.date_time).toLocaleDateString("en-IN", {
									day: "2-digit",
									month: "short",
									year: "numeric"
								}) : "Today"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-3 pr-3 font-medium",
								children: r.crime_type || "General Case"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-3 pr-3 text-secondary",
								children: r.police_station ? `${r.police_station}, ${r.district}` : r.district
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-3 pr-3",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: `text-[10.5px] font-semibold px-2 py-0.5 rounded ${toneForStatus(r.status)}`,
									children: r.status || "Under Investigation"
								})
							})
						]
					}, r.id)) })]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between mt-4 text-[11.5px] text-secondary",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					"Showing 1–",
					items.length,
					" of ",
					totalCount.toLocaleString(),
					" records"
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex gap-1",
					children: [
						"Prev",
						"1",
						"2",
						"3",
						"Next"
					].map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "h-7 min-w-7 px-2 panel-inset text-[11px] hover:text-primary",
						children: p
					}, p))
				})]
			}),
			selectedIncident && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IncidentDetailModal, {
				incident: selectedIncident,
				onClose: () => setSelectedIncident(null)
			})
		]
	});
}
//#endregion
export { ActivityTable as t };
