import { i as __toESM } from "../_runtime.mjs";
import { n as require_jsx_runtime, r as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { H as CircleCheck, J as Brain, _ as Play, n as X, o as TrendingUp, t as Zap } from "../_libs/lucide-react.mjs";
import { a as Panel, i as PageHeader, n as Btn, o as StatTile, r as Chip, t as AppShell } from "./ui-Bwzm-qoz.mjs";
import { t as api } from "./api-CLd47u8k.mjs";
import { a as YAxis, c as Line, h as Legend, i as LineChart, l as CartesianGrid, m as Tooltip, o as XAxis, p as ResponsiveContainer, r as BarChart, u as Bar } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/predictive-BAH33Qtd.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var FORECAST = Array.from({ length: 14 }, (_, i) => ({
	d: `+${i + 1}d`,
	actual: i < 7 ? 210 + Math.round(Math.sin(i) * 20 + i * 4) : null,
	predicted: 220 + Math.round(Math.cos(i / 2) * 30 + i * 5)
}));
var RISK_FALLBACK = [
	{
		area: "Bengaluru Urban",
		score: 92
	},
	{
		area: "Mysuru",
		score: 84
	},
	{
		area: "Belagavi",
		score: 78
	},
	{
		area: "Ballari",
		score: 71
	},
	{
		area: "Dharwad",
		score: 66
	},
	{
		area: "Mangaluru",
		score: 58
	}
];
function PredictivePage() {
	const [riskData, setRiskData] = (0, import_react.useState)(RISK_FALLBACK);
	const [predictions, setPredictions] = (0, import_react.useState)([]);
	const [showSimulator, setShowSimulator] = (0, import_react.useState)(false);
	const [simDistrict, setSimDistrict] = (0, import_react.useState)("Bengaluru Urban");
	const [simCrimeType, setSimCrimeType] = (0, import_react.useState)("Vehicle Theft");
	const [simVictims, setSimVictims] = (0, import_react.useState)(4);
	const [simAccused, setSimAccused] = (0, import_react.useState)(3);
	const [simResult, setSimResult] = (0, import_react.useState)(null);
	const [simLoading, setSimLoading] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		api.getRiskScores().then((data) => {
			if (data && data.items && data.items.length > 0) setRiskData(data.items.slice(0, 6).map((r) => ({
				area: r.district.replace(" Urban", ""),
				score: Math.round(r.risk_score * 100)
			})));
		});
		api.getAnomalies({ limit: 6 }).then((data) => {
			if (data && data.anomalies && data.anomalies.length > 0) setPredictions(data.anomalies.map((a) => ({
				t: `${a.crime_type} detected in ${a.district}: ${a.reason}`,
				c: Math.round((a.anomaly_score || .85) * 100),
				tag: a.severity === "High" ? "Urgent Action" : "Surveil",
				tone: a.severity === "High" ? "danger" : "warning"
			})));
			else setPredictions([
				{
					t: "Vehicle theft surge in Bengaluru Urban within 72h",
					c: 94,
					tag: "Deploy patrol",
					tone: "danger"
				},
				{
					t: "Cyber fraud ring active in Mysuru–Bengaluru",
					c: 88,
					tag: "Investigate",
					tone: "warning"
				},
				{
					t: "Gang movement predicted from Ballari to Hubli",
					c: 81,
					tag: "Alert",
					tone: "warning"
				},
				{
					t: "Chain snatching drop expected in Yeshwanthpur",
					c: 76,
					tag: "Info",
					tone: "info"
				},
				{
					t: "Narcotics hotspot forming in Mangaluru port area",
					c: 84,
					tag: "Surveil",
					tone: "danger"
				},
				{
					t: "Assault decline in Shivamogga (patrol impact)",
					c: 79,
					tag: "Positive",
					tone: "success"
				}
			]);
		});
	}, []);
	const runSimulation = async () => {
		setSimLoading(true);
		setSimResult(null);
		try {
			const res = await api.analyzeIncident({
				District_Name: simDistrict,
				crime_type: simCrimeType,
				"VICTIM COUNT": simVictims,
				"Accused Count": simAccused
			});
			setSimResult(res);
		} finally {
			setSimLoading(false);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		title: "Predictive Analytics",
		subtitle: "AI forecasts across Karnataka",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: "Predictive Analytics",
				description: "Model v4.2 · trained on 2.3M FIRs · 92.4% accuracy",
				actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					variant: "outline",
					icon: Play,
					onClick: () => setShowSimulator(true),
					children: "Simulate Task 4 Explainable AI"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					icon: Zap,
					children: "Retrain Model"
				})] })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatTile, {
						label: "Accuracy",
						value: "92.4%",
						hint: "Rolling 30 days",
						tone: "success"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatTile, {
						label: "Precision",
						value: "88.9%",
						hint: "High-risk class",
						tone: "info"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatTile, {
						label: "Recall",
						value: "86.1%",
						hint: "Coverage",
						tone: "gold"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatTile, {
						label: "Alerts Triggered",
						value: `${predictions.length || 127}`,
						hint: "Active high risk",
						tone: "warning"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-1 xl:grid-cols-2 gap-4 md:gap-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
					title: "7-day Actual vs 14-day Forecast",
					subtitle: "State-wide FIR volume prediction",
					action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
						tone: "gold",
						children: "AI v4.2"
					}),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "h-[240px]",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(LineChart, {
							data: FORECAST,
							margin: {
								top: 4,
								right: 8,
								bottom: 0,
								left: -18
							},
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
									stroke: "oklch(1 0 0 / 0.06)",
									vertical: false
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
									dataKey: "d",
									tick: {
										fontSize: 10,
										fill: "oklch(1 0 0 / 0.5)"
									},
									axisLine: false,
									tickLine: false
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
									tick: {
										fontSize: 10,
										fill: "oklch(1 0 0 / 0.5)"
									},
									axisLine: false,
									tickLine: false
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, { contentStyle: {
									background: "var(--color-navy-elev)",
									border: "1px solid var(--color-hairline)",
									borderRadius: 8,
									fontSize: 11
								} }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Legend, { wrapperStyle: { fontSize: 11 } }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
									type: "monotone",
									dataKey: "actual",
									stroke: "var(--color-info)",
									strokeWidth: 2,
									dot: { r: 2 },
									name: "Actual"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
									type: "monotone",
									dataKey: "predicted",
									stroke: "var(--color-gold)",
									strokeWidth: 2,
									strokeDasharray: "4 4",
									dot: { r: 2 },
									name: "Predicted"
								})
							]
						}) })
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
					title: "Top Predicted High-Risk Districts",
					subtitle: "Quantile Risk Engine Ranking",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "h-[240px]",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BarChart, {
							data: riskData,
							layout: "vertical",
							margin: {
								top: 4,
								right: 16,
								bottom: 0,
								left: 8
							},
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
									stroke: "oklch(1 0 0 / 0.06)",
									horizontal: false
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
									type: "number",
									tick: {
										fontSize: 10,
										fill: "oklch(1 0 0 / 0.5)"
									},
									axisLine: false,
									tickLine: false
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
									dataKey: "area",
									type: "category",
									tick: {
										fontSize: 10,
										fill: "oklch(1 0 0 / 0.7)"
									},
									axisLine: false,
									tickLine: false,
									width: 90
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, { contentStyle: {
									background: "var(--color-navy-elev)",
									border: "1px solid var(--color-hairline)",
									borderRadius: 8,
									fontSize: 11
								} }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
									dataKey: "score",
									fill: "var(--color-gold)",
									radius: [
										0,
										4,
										4,
										0
									],
									barSize: 14
								})
							]
						}) })
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
				title: "AI Predictions & Explainable Alerts",
				subtitle: "Actionable model outputs across jurisdictions",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3",
					children: predictions.map((p, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "panel-inset p-3 space-y-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start justify-between gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Brain, { className: "w-4 h-4 text-primary shrink-0 mt-0.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex-1 text-[12.5px] leading-snug",
									children: p.t
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
									tone: p.tone,
									children: p.tag
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-1.5 text-[11px] text-secondary",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingUp, { className: "w-3 h-3" }),
										" ",
										p.c,
										"% conf"
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "h-1 w-full rounded-full bg-white/5 overflow-hidden",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "h-full bg-primary",
									style: { width: `${p.c}%` }
								})
							})
						]
					}, i))
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
				title: "Model Health",
				subtitle: "Realtime AI system metrics",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-2 md:grid-cols-4 gap-3",
					children: [
						[
							"Inference Latency",
							"38ms",
							"info"
						],
						[
							"Predictions / min",
							"1,420",
							"gold"
						],
						[
							"Drift Score",
							"0.02",
							"success"
						],
						[
							"Active Outliers",
							`${predictions.length || 4}`,
							"warning"
						]
					].map(([l, v, t]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatTile, {
						label: l,
						value: v,
						tone: t
					}, l))
				})
			}),
			showSimulator && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "bg-navy-elev border hairline rounded-xl w-full max-w-lg p-5 shadow-2xl relative space-y-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => setShowSimulator(false),
							className: "absolute right-4 top-4 text-secondary hover:text-white",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "w-5 h-5" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Brain, { className: "w-5 h-5 text-primary" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "text-[16px] font-semibold",
								children: "Task 4 Explainable AI Simulator"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[12px] text-secondary",
							children: "Test live incident parameters and receive human-intelligible criminological explanations."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "text-[11px] uppercase text-secondary block mb-1",
									children: "District"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									value: simDistrict,
									onChange: (e) => setSimDistrict(e.target.value),
									className: "w-full bg-navy-card border hairline rounded px-3 py-2 text-[12.5px]",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Bengaluru Urban",
											children: "Bengaluru Urban"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Mysuru",
											children: "Mysuru"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Belagavi",
											children: "Belagavi"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Ballari",
											children: "Ballari"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Dharwad",
											children: "Dharwad"
										})
									]
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "text-[11px] uppercase text-secondary block mb-1",
									children: "Crime Type"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "text",
									value: simCrimeType,
									onChange: (e) => setSimCrimeType(e.target.value),
									className: "w-full bg-navy-card border hairline rounded px-3 py-2 text-[12.5px]"
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "text-[11px] uppercase text-secondary block mb-1",
									children: "Victim Count"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "number",
									value: simVictims,
									onChange: (e) => setSimVictims(Number(e.target.value)),
									className: "w-full bg-navy-card border hairline rounded px-3 py-2 text-[12.5px]"
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "text-[11px] uppercase text-secondary block mb-1",
									children: "Accused Count"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "number",
									value: simAccused,
									onChange: (e) => setSimAccused(Number(e.target.value)),
									className: "w-full bg-navy-card border hairline rounded px-3 py-2 text-[12.5px]"
								})] })
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
							icon: Zap,
							onClick: runSimulation,
							className: "w-full justify-center",
							children: simLoading ? "Analyzing..." : "Run AI Explainability Engine"
						}),
						simResult && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "panel-inset p-3.5 space-y-2 text-[12px] border-l-4 border-primary",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between font-semibold",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Risk Category: ", simResult.risk_category] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-primary font-mono",
										children: [
											"Score: ",
											simResult.hotspot_score,
											"/10"
										]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-secondary leading-relaxed",
									children: simResult.explanation_text
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-1 pt-2 border-t hairline",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-[11px] uppercase font-semibold text-secondary",
										children: "Explainable Insights:"
									}), simResult.explainable_insights?.map((ins, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-start gap-1.5 text-[11.5px]",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "w-3.5 h-3.5 text-primary shrink-0 mt-0.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: ins })]
									}, idx))]
								})
							]
						})
					]
				})
			})
		]
	});
}
//#endregion
export { PredictivePage as component };
