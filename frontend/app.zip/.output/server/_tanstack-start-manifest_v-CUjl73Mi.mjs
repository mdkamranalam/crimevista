//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CUjl73Mi.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/Users/md.kamranalam/Programming/hackathon/crimevista/frontend/src/routes/__root.tsx",
		children: [
			"/",
			"/admin",
			"/alerts",
			"/cases",
			"/district",
			"/fir",
			"/heatmap",
			"/login",
			"/predictive",
			"/relationships",
			"/reports"
		],
		preloads: ["/assets/index-DfeREZQd.js", "/assets/useRouter-BJ5XiiId.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DfeREZQd.js"
		} }]
	},
	"/": {
		filePath: "/Users/md.kamranalam/Programming/hackathon/crimevista/frontend/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-DLpRtZs2.js",
			"/assets/ui-DhIGVfx4.js",
			"/assets/vidhana-soudha-C2NJXAbl.js",
			"/assets/ActivityTable-D-ro4Hh-.js",
			"/assets/file-text-Dm7KTrof.js",
			"/assets/HeatmapPanel-ew4tGRvq.js",
			"/assets/trending-up--3oXnN4n.js",
			"/assets/Skeleton-CPsD2KF_.js",
			"/assets/shield-B296Q3cE.js",
			"/assets/triangle-alert-DlpzYuo6.js",
			"/assets/users-Brvu2NZ5.js",
			"/assets/api-BpDSqdlt.js",
			"/assets/generateCategoricalChart-Ej4NmLwN.js",
			"/assets/AreaChart-BDm7Oqw4.js",
			"/assets/BarChart-CMJ0NE2e.js"
		]
	},
	"/admin": {
		filePath: "/Users/md.kamranalam/Programming/hackathon/crimevista/frontend/src/routes/admin.tsx",
		children: void 0,
		preloads: [
			"/assets/admin-DN9kFy2j.js",
			"/assets/ui-DhIGVfx4.js",
			"/assets/vidhana-soudha-C2NJXAbl.js",
			"/assets/plus-Qxg_mSsw.js",
			"/assets/shield-B296Q3cE.js",
			"/assets/users-Brvu2NZ5.js"
		]
	},
	"/alerts": {
		filePath: "/Users/md.kamranalam/Programming/hackathon/crimevista/frontend/src/routes/alerts.tsx",
		children: void 0,
		preloads: [
			"/assets/alerts-BDffFfmL.js",
			"/assets/ui-DhIGVfx4.js",
			"/assets/vidhana-soudha-C2NJXAbl.js",
			"/assets/funnel-IG-KEPFp.js",
			"/assets/triangle-alert-DlpzYuo6.js"
		]
	},
	"/cases": {
		filePath: "/Users/md.kamranalam/Programming/hackathon/crimevista/frontend/src/routes/cases.tsx",
		children: void 0,
		preloads: [
			"/assets/cases-DyjZtA8n.js",
			"/assets/ui-DhIGVfx4.js",
			"/assets/ActivityTable-D-ro4Hh-.js",
			"/assets/file-text-Dm7KTrof.js",
			"/assets/funnel-IG-KEPFp.js",
			"/assets/plus-Qxg_mSsw.js",
			"/assets/user-ClGptIgL.js",
			"/assets/api-BpDSqdlt.js"
		]
	},
	"/district": {
		filePath: "/Users/md.kamranalam/Programming/hackathon/crimevista/frontend/src/routes/district.tsx",
		children: void 0,
		preloads: [
			"/assets/district-BMRrbela.js",
			"/assets/ui-DhIGVfx4.js",
			"/assets/HeatmapPanel-ew4tGRvq.js",
			"/assets/api-BpDSqdlt.js",
			"/assets/generateCategoricalChart-Ej4NmLwN.js",
			"/assets/AreaChart-BDm7Oqw4.js"
		]
	},
	"/fir": {
		filePath: "/Users/md.kamranalam/Programming/hackathon/crimevista/frontend/src/routes/fir.tsx",
		children: void 0,
		preloads: [
			"/assets/fir-Dvpk6C_y.js",
			"/assets/ui-DhIGVfx4.js",
			"/assets/vidhana-soudha-C2NJXAbl.js",
			"/assets/file-text-Dm7KTrof.js",
			"/assets/download-BXSkJsC0.js",
			"/assets/eye-DgGbFkfq.js",
			"/assets/funnel-IG-KEPFp.js",
			"/assets/plus-Qxg_mSsw.js",
			"/assets/api-BpDSqdlt.js",
			"/assets/IncidentDetailModal-B0XsUN7g.js",
			"/assets/generateCategoricalChart-Ej4NmLwN.js",
			"/assets/AreaChart-BDm7Oqw4.js"
		]
	},
	"/heatmap": {
		filePath: "/Users/md.kamranalam/Programming/hackathon/crimevista/frontend/src/routes/heatmap.tsx",
		children: void 0,
		preloads: [
			"/assets/heatmap-B1RA03_Q.js",
			"/assets/ui-DhIGVfx4.js",
			"/assets/vidhana-soudha-C2NJXAbl.js",
			"/assets/HeatmapPanel-ew4tGRvq.js",
			"/assets/download-BXSkJsC0.js",
			"/assets/funnel-IG-KEPFp.js",
			"/assets/Skeleton-CPsD2KF_.js",
			"/assets/api-BpDSqdlt.js"
		]
	},
	"/login": {
		filePath: "/Users/md.kamranalam/Programming/hackathon/crimevista/frontend/src/routes/login.tsx",
		children: void 0,
		preloads: [
			"/assets/login-B_-43kHx.js",
			"/assets/vidhana-soudha-C2NJXAbl.js",
			"/assets/eye-DgGbFkfq.js",
			"/assets/shield-B296Q3cE.js",
			"/assets/user-ClGptIgL.js"
		]
	},
	"/predictive": {
		filePath: "/Users/md.kamranalam/Programming/hackathon/crimevista/frontend/src/routes/predictive.tsx",
		children: void 0,
		preloads: [
			"/assets/predictive-NYaLusHH.js",
			"/assets/ui-DhIGVfx4.js",
			"/assets/vidhana-soudha-C2NJXAbl.js",
			"/assets/trending-up--3oXnN4n.js",
			"/assets/zap-8q7DN0bj.js",
			"/assets/api-BpDSqdlt.js",
			"/assets/generateCategoricalChart-Ej4NmLwN.js",
			"/assets/BarChart-CMJ0NE2e.js"
		]
	},
	"/relationships": {
		filePath: "/Users/md.kamranalam/Programming/hackathon/crimevista/frontend/src/routes/relationships.tsx",
		children: void 0,
		preloads: [
			"/assets/relationships-Dc14Ap1L.js",
			"/assets/ui-DhIGVfx4.js",
			"/assets/download-BXSkJsC0.js",
			"/assets/user-ClGptIgL.js",
			"/assets/users-Brvu2NZ5.js",
			"/assets/zap-8q7DN0bj.js",
			"/assets/api-BpDSqdlt.js"
		]
	},
	"/reports": {
		filePath: "/Users/md.kamranalam/Programming/hackathon/crimevista/frontend/src/routes/reports.tsx",
		children: void 0,
		preloads: [
			"/assets/reports-DA8H1AkV.js",
			"/assets/ui-DhIGVfx4.js",
			"/assets/file-text-Dm7KTrof.js",
			"/assets/download-BXSkJsC0.js",
			"/assets/funnel-IG-KEPFp.js",
			"/assets/generateCategoricalChart-Ej4NmLwN.js",
			"/assets/BarChart-CMJ0NE2e.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
